package examclone;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewQuestionsFrame extends JFrame {
    private JTextField examCodeField;
    private JTable questionTable;
    private DefaultTableModel tableModel;

    public ViewQuestionsFrame() {
        setTitle("View Questions by Exam Code");
        setSize(1000, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Top Panel
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Enter Exam Code:"));

        examCodeField = new JTextField(15);
        JButton searchBtn = new JButton("Search");

        topPanel.add(examCodeField);
        topPanel.add(searchBtn);
        add(topPanel, BorderLayout.NORTH);

        // Table setup
        String[] columns = {"ID", "Question", "A", "B", "C", "D", "Correct", "Edit"};
        tableModel = new DefaultTableModel(null, columns) {
            public boolean isCellEditable(int row, int column) {
                return column == 7; // Only "Edit" column is editable (button)
            }
        };
        questionTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(questionTable);
        add(scrollPane, BorderLayout.CENTER);

        // Add Button Renderer and Editor
        questionTable.getColumn("Edit").setCellRenderer(new ButtonRenderer());
        questionTable.getColumn("Edit").setCellEditor(new ButtonEditor(new JCheckBox()));

        // Search button action
        searchBtn.addActionListener(e -> {
            String examCode = examCodeField.getText().trim();
            if (examCode.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter exam code");
            } else {
                loadQuestions(examCode);
            }
        });
    }

    private void loadQuestions(String examCode) {
        tableModel.setRowCount(0);
        try {
            Conn conn = new Conn();
            PreparedStatement pst = conn.c.prepareStatement(
                "SELECT * FROM questions WHERE exam_code = ?"
            );
            pst.setString(1, examCode);
            ResultSet rs = pst.executeQuery();

            boolean found = false;
            while (rs.next()) {
                found = true;
                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("question_text"),
                    rs.getString("option_a"),
                    rs.getString("option_b"),
                    rs.getString("option_c"),
                    rs.getString("option_d"),
                    rs.getString("correct_answer"),
                    "Edit"
                });
            }
            if (!found) {
                JOptionPane.showMessageDialog(this, "No questions found for this exam code.");
            }

            rs.close();
            pst.close();
            conn.c.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Button Renderer
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            setText((value == null) ? "Edit" : value.toString());
            return this;
        }
    }

    // Button Editor
    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean clicked;
        private int row;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);

            button.addActionListener(e -> fireEditingStopped());
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            this.row = row;
            label = (value == null) ? "Edit" : value.toString();
            button.setText(label);
            clicked = true;
            return button;
        }

        public Object getCellEditorValue() {
            if (clicked) {
                int id = (int) tableModel.getValueAt(row, 0); // Get question ID
                editQuestion(id); // Call your edit logic
            }
            clicked = false;
            return label;
        }

        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }

        private void editQuestion(int id) {
            JOptionPane.showMessageDialog(null, "Open Edit Form for Question ID: " + id);
            new EditQuestionFrame(id).setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewQuestionsFrame().setVisible(true));
    }
}
