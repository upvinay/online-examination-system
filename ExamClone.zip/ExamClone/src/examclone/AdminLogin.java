package examclone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminLogin extends JFrame {

    public AdminLogin() {
        super("Admin Login - Online Examination System");

        setSize(500, 400);
        setLocationRelativeTo(null); // Center on screen
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // Background image
        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/backgroundimg.gif"));
        Image bgImage = bgIcon.getImage().getScaledInstance(500, 400, Image.SCALE_SMOOTH);
        JLabel background = new JLabel(new ImageIcon(bgImage));
        background.setBounds(0, 0, 500, 400);
        background.setLayout(null);
        setContentPane(background);

        // Shadow container
        JPanel shadowPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setColor(new Color(0, 0, 0, 50));
                g2d.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 30, 30);
                super.paintComponent(g);
            }
        };
        shadowPanel.setOpaque(false);
        shadowPanel.setBounds(45, 45, 410, 290);
        background.add(shadowPanel);

        // Login panel with translucent background
        JPanel formPanel = new JPanel(null);
        formPanel.setBounds(50, 50, 400, 280);
        formPanel.setBackground(Color.black);
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 100, 80), 1));
        background.add(formPanel);

        // Gradient heading
        JLabel heading = new JLabel("Admin Login") {
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(255, 140, 0), getWidth(), getHeight(), new Color(255, 255, 255));
                g2d.setPaint(gp);
                g2d.setFont(getFont());
                g2d.drawString(getText(), 0, getHeight() - 10);
            }
        };
        heading.setFont(new Font("Segoe UI", Font.BOLD, 30));
        heading.setBounds(110, 10, 200, 40);
        formPanel.add(heading);

        // Username
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
        userLabel.setForeground(Color.white);
        userLabel.setBounds(30, 70, 120, 25);
        formPanel.add(userLabel);

        JTextField usernameField = new JTextField();
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        usernameField.setBounds(150, 70, 200, 30);
        formPanel.add(usernameField);

        // Password
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Times New Roman", Font.BOLD, 22));
        passLabel.setBounds(30, 120, 120, 25);
        passLabel.setForeground(Color.white);
        formPanel.add(passLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        passwordField.setBounds(150, 120, 200, 30);
        formPanel.add(passwordField);

        // Login Button
        JButton loginBtn = new JButton("Login");
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        loginBtn.setBackground(Color.DARK_GRAY);
        loginBtn.setForeground(Color.ORANGE);
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(BorderFactory.createEmptyBorder());
        loginBtn.setBounds(140, 180, 120, 35);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        formPanel.add(loginBtn);

        // Login action using DB
        loginBtn.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter both username and password.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (authenticateAdmin(username, password)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose();
                new AdminDashboard().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private boolean authenticateAdmin(String username, String password) {
        try {
            Conn conn = new Conn(); // Using your Conn class
            String query = "SELECT * FROM admins WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.c.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // true if matching row found
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database connection error!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminLogin login = new AdminLogin();
            login.setType(Window.Type.UTILITY);
            login.setVisible(true);
        });
    }
}
