package examclone;

import javax.swing.*;
import java.awt.*;

public class AddAdminFrame extends JFrame {
    public AddAdminFrame() {
        setTitle("Add New Admin");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("Username:"));
        JTextField usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password:"));
        JPasswordField passwordField = new JPasswordField();
        add(passwordField);

        add(new JLabel("Confirm Password:"));
        JPasswordField confirmField = new JPasswordField();
        add(confirmField);

        JButton submit = new JButton("Add Admin");
        add(new JLabel()); // Empty cell
        add(submit);

        submit.addActionListener(e -> {
            // Add admin to DB
            JOptionPane.showMessageDialog(this, "New Admin Added Successfully!");
            dispose();
        });
    }
}
