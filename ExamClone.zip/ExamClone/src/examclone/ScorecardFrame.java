package examclone;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.sql.*;

public class ScorecardFrame extends JFrame {

    private JComboBox<String> examCodeCombo;
    private JTextField regNoField;
    private JPanel resultPanel;
    private JButton printBtn;

    public ScorecardFrame() {
        super("Student Scorecard");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Soft background color
        getContentPane().setBackground(new Color(240, 245, 250));

        // Top Panel: Search Controls
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 15));
        topPanel.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 2, 0, new Color(100, 149, 237)),  // subtle blue bottom border
            new EmptyBorder(10, 10, 10, 10)
        ));
        topPanel.setBackground(new Color(220, 230, 255));

        examCodeCombo = new JComboBox<>();
        loadExamCodes();

        regNoField = new JTextField(16);
        setPlaceholder(regNoField, "Enter Registration No");

        JButton searchBtn = createStyledButton("Search");
        printBtn = createStyledButton("Print Scorecard");
        printBtn.setEnabled(false);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        JLabel examCodeLabel = new JLabel("Exam Code:");
        examCodeLabel.setFont(labelFont);
        examCodeLabel.setForeground(new Color(30, 60, 120));
        JLabel regNoLabel = new JLabel("Registration No:");
        regNoLabel.setFont(labelFont);
        regNoLabel.setForeground(new Color(30, 60, 120));

        topPanel.add(examCodeLabel);
        topPanel.add(examCodeCombo);
        topPanel.add(regNoLabel);
        topPanel.add(regNoField);
        topPanel.add(searchBtn);
        topPanel.add(printBtn);

        add(topPanel, BorderLayout.NORTH);

        // Result Panel
        resultPanel = new JPanel();
        resultPanel.setLayout(new BoxLayout(resultPanel, BoxLayout.Y_AXIS));
        resultPanel.setBorder(new EmptyBorder(15, 20, 20, 20));
        JScrollPane scrollPane = new JScrollPane(resultPanel);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane, BorderLayout.CENTER);

        // Event Listeners
        searchBtn.addActionListener(e -> searchResult());
        printBtn.addActionListener(e -> printScorecard());
    }

    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(new Color(65, 105, 225));
        btn.setForeground(Color.WHITE);
        btn.setBorder(new RoundedBorder(12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(100, 149, 237));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(65, 105, 225));
            }
        });

        return btn;
    }

    private void setPlaceholder(JTextField field, String placeholder) {
        field.setForeground(Color.GRAY);
        field.setText(placeholder);
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }
            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setForeground(Color.GRAY);
                    field.setText(placeholder);
                }
            }
        });
    }

    private void loadExamCodes() {
        try {
            Conn conn = new Conn();
            ResultSet rs = conn.c.createStatement().executeQuery("SELECT DISTINCT exam_code FROM results");
            while (rs.next()) {
                examCodeCombo.addItem(rs.getString("exam_code"));
            }
            rs.close();
            conn.c.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading exam codes:\n" + e.getMessage());
        }
    }

    private void searchResult() {
        resultPanel.removeAll();
        printBtn.setEnabled(false);

        String examCode = (String) examCodeCombo.getSelectedItem();
        String regNo = regNoField.getText().trim();

        if (regNo.isEmpty() || regNo.equals("Enter Registration No")) {
            JOptionPane.showMessageDialog(this, "Please enter Registration Number.");
            return;
        }

        try {
            Conn conn = new Conn();

            // Fetch Student Details
            String studentSql = "SELECT * FROM students WHERE reg_no = ?";
            PreparedStatement pst1 = conn.c.prepareStatement(studentSql);
            pst1.setString(1, regNo);
            ResultSet rs1 = pst1.executeQuery();

            if (!rs1.next()) {
                JOptionPane.showMessageDialog(this, "No student found with Registration No: " + regNo);
                return;
            }

            JPanel studentPanel = new JPanel(new GridLayout(0, 2, 15, 15));
            studentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(100, 149, 237), 2, true), 
                "Student Details",
                0, 0, new Font("Segoe UI", Font.BOLD, 18),
                new Color(30, 60, 120)));
            studentPanel.setBackground(new Color(235, 245, 255));

            Font infoFont = new Font("Segoe UI", Font.PLAIN, 16);
            Color labelColor = new Color(40, 70, 120);

            addInfoLabel(studentPanel, "Name:", rs1.getString("name"), infoFont, labelColor);
            addInfoLabel(studentPanel, "Father's Name:", rs1.getString("father_name"), infoFont, labelColor);
            addInfoLabel(studentPanel, "Mother's Name:", rs1.getString("mother_name"), infoFont, labelColor);
            addInfoLabel(studentPanel, "DOB:", rs1.getDate("dob").toString(), infoFont, labelColor);
            addInfoLabel(studentPanel, "Phone:", rs1.getString("phone"), infoFont, labelColor);
            addInfoLabel(studentPanel, "Email:", rs1.getString("email"), infoFont, labelColor);
            addInfoLabel(studentPanel, "City:", rs1.getString("city"), infoFont, labelColor);
            addInfoLabel(studentPanel, "State:", rs1.getString("state"), infoFont, labelColor);

            resultPanel.add(studentPanel);

            rs1.close();
            pst1.close();

            // Fetch Exam Result
            String resultSql = "SELECT * FROM results WHERE reg_no = ? AND exam_code = ?";
            PreparedStatement pst2 = conn.c.prepareStatement(resultSql);
            pst2.setString(1, regNo);
            pst2.setString(2, examCode);
            ResultSet rs2 = pst2.executeQuery();

            if (rs2.next()) {
                JPanel scorePanel = new JPanel(new GridLayout(0, 2, 15, 15));
                scorePanel.setBorder(BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(new Color(255, 140, 0), 2, true),
                    "Scorecard",
                    0, 0, new Font("Segoe UI", Font.BOLD, 18),
                    new Color(255, 140, 0)));
                scorePanel.setBackground(new Color(255, 250, 240));

                addInfoLabel(scorePanel, "Exam Code:", rs2.getString("exam_code"), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Total Questions:", String.valueOf(rs2.getInt("total_questions")), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Attempted:", String.valueOf(rs2.getInt("attempted")), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Correct:", String.valueOf(rs2.getInt("correct")), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Wrong:", String.valueOf(rs2.getInt("wrong")), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Not Attempted:", String.valueOf(rs2.getInt("not_attempted")), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Score:", String.format("%.2f", rs2.getFloat("score")), infoFont, new Color(120, 60, 0));
                addInfoLabel(scorePanel, "Full Marks:", String.format("%.2f", rs2.getFloat("full_marks")), infoFont, new Color(120, 60, 0));

                resultPanel.add(Box.createVerticalStrut(20));
                resultPanel.add(scorePanel);

                printBtn.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "No result found for Registration No: " + regNo + " and Exam Code: " + examCode);
            }

            rs2.close();
            pst2.close();
            conn.c.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error:\n" + ex.getMessage());
        }

        resultPanel.revalidate();
        resultPanel.repaint();
    }

    private void addInfoLabel(JPanel panel, String label, String value, Font font, Color fg) {
        JLabel lblKey = new JLabel(label);
        lblKey.setFont(font.deriveFont(Font.BOLD));
        lblKey.setForeground(fg);
        JLabel lblValue = new JLabel(value);
        lblValue.setFont(font);
        lblValue.setForeground(fg.darker());
        panel.add(lblKey);
        panel.add(lblValue);
    }

    private void printScorecard() {
        if (resultPanel.getComponentCount() == 0) {
            JOptionPane.showMessageDialog(this, "Nothing to print. Please search first.");
            return;
        }

        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Scorecard");

        job.setPrintable((g, pf, pageIndex) -> {
            if (pageIndex > 0) return Printable.NO_SUCH_PAGE;

            Graphics2D g2d = (Graphics2D) g;
            g2d.translate(pf.getImageableX(), pf.getImageableY());

            double scaleX = pf.getImageableWidth() / resultPanel.getWidth();
            double scaleY = pf.getImageableHeight() / resultPanel.getHeight();
            double scale = Math.min(scaleX, scaleY);
            g2d.scale(scale, scale);

            resultPanel.paint(g2d);
            return Printable.PAGE_EXISTS;
        });

        if (job.printDialog()) {
            try {
                job.print();
            } catch (PrinterException e) {
                JOptionPane.showMessageDialog(this, "Printing failed: " + e.getMessage());
            }
        }
    }

    // Custom rounded border for buttons
    private static class RoundedBorder implements Border {
        private int radius;

        RoundedBorder(int radius) {
            this.radius = radius;
        }

        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius+1, this.radius+1, this.radius+2, this.radius);
        }

        public boolean isBorderOpaque() {
            return false;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.setColor(new Color(65, 105, 225));
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ScorecardFrame().setVisible(true);
        });
    }
}
