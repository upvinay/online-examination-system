package examclone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StartPage extends JFrame {

    public StartPage() {
        super("Online Examination System");

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

       
        JPanel toolbar = new JPanel(null);
        toolbar.setBounds(0, 0, 1300, 80);
        toolbar.setBackground(new Color(25, 25, 112)); // Dark blue
        add(toolbar);

        
        JButton studentLoginBtn = createToolbarButton("Student", "examclone/icon/student1.jpg", new Color(255, 228, 225));
        JButton adminLoginBtn = createToolbarButton("Admin", "examclone/icon/admin1.jpg", new Color(224, 255, 255));
        JButton exitBtn = createToolbarButton("Exit", "examclone/icon/exit.png", new Color(255, 240, 245));

       
        studentLoginBtn.setBounds(10, 5, 100, 70);
        adminLoginBtn.setBounds(130, 5, 100, 70);
        exitBtn.setBounds(250, 5, 100, 70);

       
        toolbar.add(studentLoginBtn);
        toolbar.add(adminLoginBtn);
        toolbar.add(exitBtn);

       
        JLabel title = new JLabel("Online Examination System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 48));
        title.setForeground(Color.ORANGE);
        title.setBounds(500, 10, 1000, 60);
        toolbar.add(title); 

        
        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/load.png"));
        Image bgImage = bgIcon.getImage().getScaledInstance(1300, 680, Image.SCALE_SMOOTH); 
        JLabel background = new JLabel(new ImageIcon(bgImage));
        background.setBounds(0, 80, 1300, 680); 
        add(background);


        studentLoginBtn.addActionListener(e -> {
            new StudentLogin().setVisible(true);
           
        });

        adminLoginBtn.addActionListener(e -> {
            
            new AdminLogin().setVisible(true);
        });

        exitBtn.addActionListener(e -> System.exit(0));
    }

    private JButton createToolbarButton(String text, String iconPath, Color bgColor) {
        ImageIcon icon = null;
        try {
            icon = new ImageIcon(ClassLoader.getSystemResource(iconPath));
            Image img = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        } catch (Exception e) {
            System.out.println("Icon not found: " + iconPath);
        }

        JButton button = new JButton(text, icon);
        button.setFocusPainted(false);
        button.setVerticalTextPosition(SwingConstants.TOP);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setBackground(bgColor);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StartPage().setVisible(true));
    }
}
