package examclone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentLogin extends JFrame {

    JTextField regNoField;
    JPasswordField passwordField;

    public StudentLogin() {
        setTitle("Student Login");
        setSize(450, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header Panel
        JLabel titleLabel = new JLabel("Student Login Portal", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(33, 150, 243));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Input Panel
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Registration Number
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Registration No:"), gbc);

        gbc.gridx = 1;
        regNoField = new JTextField();
        styleTextField(regNoField);
        panel.add(regNoField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField();
        styleTextField(passwordField);
        panel.add(passwordField, gbc);

        // Login Button
        gbc.gridx = 1;
        gbc.gridy = 2;
        JButton loginBtn = new JButton("Login");
        styleButton(loginBtn);
        loginBtn.addActionListener(e -> verifyLogin());
        panel.add(loginBtn, gbc);

        add(panel, BorderLayout.CENTER);
        getContentPane().setBackground(Color.WHITE);
        setVisible(true);
    }

    private void styleTextField(JTextField field) {
        field.setPreferredSize(new Dimension(200, 30));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 15));
        button.setBackground(new Color(33, 150, 243));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(30, 136, 229));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(33, 150, 243));
            }
        });
    }

    private void verifyLogin() {
        String regNo = regNoField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (regNo.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Conn c = new Conn(); // Your DB connection class

            String query = "SELECT * FROM studentlogin WHERE reg_no = ? AND dob = ?";
            PreparedStatement ps = c.c.prepareStatement(query);
            ps.setString(1, regNo);
            ps.setString(2, password); // Assuming DOB is used as password

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String examCode = rs.getString("exam_code");

                String subject = null;
                String query1 = "SELECT * FROM exams WHERE exam_code = ?";
                PreparedStatement ps1 = c.c.prepareStatement(query1);
                ps1.setString(1, examCode);
                ResultSet rs1 = ps1.executeQuery();

                if (rs1.next()) {
                    subject = rs1.getString("subject");
                } else {
                    JOptionPane.showMessageDialog(this, "Exam code not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                JOptionPane.showMessageDialog(this, "Login Successful!\nWelcome " + name);
                dispose(); // Close login window
                new ExamPanel(regNo, name, examCode, subject); // <-- Pass all values

                rs1.close();
                ps1.close();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Registration No or DOB (Password)!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

            rs.close();
            ps.close();
            c.c.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentLogin::new);
    }
}
