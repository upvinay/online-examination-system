package examclone;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class UpdateStudentForm extends JFrame {

    private JTextField searchField;
    private JButton searchButton;

    private JTextField regField;
    private JTextField nameField;
    private JTextField fatherField;
    private JTextField motherField;
    private JDateChooser dobChooser;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField adharField;
    private JTextField cityField;
    private JTextField pinField;
    private JComboBox<String> stateCombo;
    private JButton updateButton;

    public UpdateStudentForm() {
        setTitle("Update Student Details");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel searchLabel = new JLabel("Enter Registration Number:");
        searchLabel.setBounds(30, 20, 180, 25);
        add(searchLabel);

        searchField = new JTextField();
        searchField.setBounds(220, 20, 200, 25);
        add(searchField);

        searchButton = new JButton("Search");
        searchButton.setBounds(440, 20, 100, 25);
        add(searchButton);

        int labelX = 30, fieldX = 220;
        int yStart = 70, yGap = 40;

        JLabel regLabel = new JLabel("Registration Number:");
        regLabel.setBounds(labelX, yStart, 180, 25);
        add(regLabel);

        regField = new JTextField();
        regField.setBounds(fieldX, yStart, 320, 25);
        regField.setEditable(false);
        add(regField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(labelX, yStart + yGap, 180, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(fieldX, yStart + yGap, 320, 25);
        nameField.setEditable(false);
        add(nameField);

        JLabel fatherLabel = new JLabel("Father's Name:");
        fatherLabel.setBounds(labelX, yStart + 2 * yGap, 180, 25);
        add(fatherLabel);

        fatherField = new JTextField();
        fatherField.setBounds(fieldX, yStart + 2 * yGap, 320, 25);
        add(fatherField);

        JLabel motherLabel = new JLabel("Mother's Name:");
        motherLabel.setBounds(labelX, yStart + 3 * yGap, 180, 25);
        add(motherLabel);

        motherField = new JTextField();
        motherField.setBounds(fieldX, yStart + 3 * yGap, 320, 25);
        add(motherField);

        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setBounds(labelX, yStart + 4 * yGap, 180, 25);
        add(dobLabel);

        dobChooser = new JDateChooser();
        dobChooser.setBounds(fieldX, yStart + 4 * yGap, 320, 25);
        dobChooser.setDateFormatString("dd-MM-yyyy");
        add(dobChooser);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(labelX, yStart + 5 * yGap, 180, 25);
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(fieldX, yStart + 5 * yGap, 320, 25);
        add(phoneField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(labelX, yStart + 6 * yGap, 180, 25);
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(fieldX, yStart + 6 * yGap, 320, 25);
        add(emailField);

        JLabel adharLabel = new JLabel("Adhar Number:");
        adharLabel.setBounds(labelX, yStart + 7 * yGap, 180, 25);
        add(adharLabel);

        adharField = new JTextField();
        adharField.setBounds(fieldX, yStart + 7 * yGap, 320, 25);
        add(adharField);

        JLabel cityLabel = new JLabel("City:");
        cityLabel.setBounds(labelX, yStart + 8 * yGap, 180, 25);
        add(cityLabel);

        cityField = new JTextField();
        cityField.setBounds(fieldX, yStart + 8 * yGap, 320, 25);
        add(cityField);

        JLabel pinLabel = new JLabel("PIN Code:");
        pinLabel.setBounds(labelX, yStart + 9 * yGap, 180, 25);
        add(pinLabel);

        pinField = new JTextField();
        pinField.setBounds(fieldX, yStart + 9 * yGap, 320, 25);
        add(pinField);

        JLabel stateLabel = new JLabel("State:");
        stateLabel.setBounds(labelX, yStart + 10 * yGap, 180, 25);
        add(stateLabel);

        String[] states = {
            "Select State", "Andhra Pradesh", "Bihar", "Delhi", "Goa", "Gujarat",
            "Haryana", "Karnataka", "Kerala", "Maharashtra", "Punjab", "Rajasthan",
            "Tamil Nadu", "Uttar Pradesh", "West Bengal"
        };
        stateCombo = new JComboBox<>(states);
        stateCombo.setBounds(fieldX, yStart + 10 * yGap, 320, 25);
        add(stateCombo);

        updateButton = new JButton("Update");
        updateButton.setBounds(fieldX, yStart + 11 * yGap + 10, 150, 35);
        add(updateButton);

        setFormEnabled(false);

        searchButton.addActionListener(e -> searchStudent());
        updateButton.addActionListener(e -> updateStudent());
    }

    private void setFormEnabled(boolean enabled) {
        fatherField.setEnabled(enabled);
        motherField.setEnabled(enabled);
        dobChooser.setEnabled(enabled);
        phoneField.setEnabled(enabled);
        emailField.setEnabled(enabled);
        adharField.setEnabled(enabled);
        cityField.setEnabled(enabled);
        pinField.setEnabled(enabled);
        stateCombo.setEnabled(enabled);
        updateButton.setEnabled(enabled);
    }

    private void searchStudent() {
        String regNo = searchField.getText().trim();
        if (regNo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a registration number", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            Conn c = new Conn();
            String query = "SELECT * FROM students WHERE reg_no = '" + regNo + "'";
            ResultSet rs = c.s.executeQuery(query);

            if (rs.next()) {
                regField.setText(rs.getString("reg_no"));
                nameField.setText(rs.getString("name"));
                fatherField.setText(rs.getString("father_name"));
                motherField.setText(rs.getString("mother_name"));
                dobChooser.setDate(rs.getDate("dob"));
                phoneField.setText(rs.getString("phone"));
                emailField.setText(rs.getString("email"));
                adharField.setText(rs.getString("aadhar"));
                cityField.setText(rs.getString("city"));
                pinField.setText(rs.getString("pin_code"));
                stateCombo.setSelectedItem(rs.getString("state"));
                setFormEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Student not found!", "Error", JOptionPane.ERROR_MESSAGE);
                clearForm();
                setFormEnabled(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clearForm() {
        regField.setText("");
        nameField.setText("");
        fatherField.setText("");
        motherField.setText("");
        dobChooser.setDate(null);
        phoneField.setText("");
        emailField.setText("");
        adharField.setText("");
        cityField.setText("");
        pinField.setText("");
        stateCombo.setSelectedIndex(0);
    }

    private void updateStudent() {
        Date dob = dobChooser.getDate();

        if (fatherField.getText().trim().isEmpty()
                || motherField.getText().trim().isEmpty()
                || dob == null
                || phoneField.getText().trim().isEmpty()
                || emailField.getText().trim().isEmpty()
                || adharField.getText().trim().isEmpty()
                || cityField.getText().trim().isEmpty()
                || pinField.getText().trim().isEmpty()
                || stateCombo.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

// ✅ DOB validation: must be at least 6 years before today
        Date today = new Date();
        long sixYearsInMillis = (long) (6L * 365.25 * 24 * 60 * 60 * 1000);
        Date sixYearsAgo = new Date(today.getTime() - sixYearsInMillis);

        if (!dob.before(sixYearsAgo)) {
            JOptionPane.showMessageDialog(this, "Student must be at least 6 years old.", "Invalid DOB", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Conn c = new Conn();
            String dobStr = new java.sql.Date(dobChooser.getDate().getTime()).toString();

            String sql = "UPDATE students SET "
                    + "father_name = '" + fatherField.getText().trim() + "', "
                    + "mother_name = '" + motherField.getText().trim() + "', "
                    + "dob = '" + dobStr + "', "
                    + "phone = '" + phoneField.getText().trim() + "', "
                    + "email = '" + emailField.getText().trim() + "', "
                    + "aadhar = '" + adharField.getText().trim() + "', "
                    + "city = '" + cityField.getText().trim() + "', "
                    + "pin_code = '" + pinField.getText().trim() + "', "
                    + "state = '" + stateCombo.getSelectedItem() + "' "
                    + "WHERE reg_no = '" + regField.getText().trim() + "'";

            int rows = c.s.executeUpdate(sql);
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Student details updated successfully!");
                clearForm();
                setFormEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update student.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new UpdateStudentForm().setVisible(true);
        });
    }
}
