package examclone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class EditQuestionFrame extends JFrame {
    private int questionId;

    private JTextField questionField, optionAField, optionBField, optionCField, optionDField, correctAnswerField;

    public EditQuestionFrame(int questionId) {
        this.questionId = questionId;

        setTitle("✏️ Edit Question");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(Color.WHITE);

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 16);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 15);

        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 10, 30));
        formPanel.setBackground(Color.WHITE);

        // Add components
        formPanel.add(makeLabel("Question Text:", labelFont));
        questionField = makeField(fieldFont);
        formPanel.add(questionField);

        formPanel.add(makeLabel("Option A:", labelFont));
        optionAField = makeField(fieldFont);
        formPanel.add(optionAField);

        formPanel.add(makeLabel("Option B:", labelFont));
        optionBField = makeField(fieldFont);
        formPanel.add(optionBField);

        formPanel.add(makeLabel("Option C:", labelFont));
        optionCField = makeField(fieldFont);
        formPanel.add(optionCField);

        formPanel.add(makeLabel("Option D:", labelFont));
        optionDField = makeField(fieldFont);
        formPanel.add(optionDField);

        formPanel.add(makeLabel("Correct Answer (A/B/C/D):", labelFont));
        correctAnswerField = makeField(fieldFont);
        formPanel.add(correctAnswerField);

        add(formPanel, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(Color.WHITE);

        JButton updateBtn = makeButton(" Update", new Color(0, 123, 255), Color.WHITE);
        JButton cancelBtn = makeButton(" Cancel", Color.GRAY, Color.WHITE);

        buttonPanel.add(updateBtn);
        buttonPanel.add(cancelBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        // Action Listeners
        updateBtn.addActionListener(e -> updateQuestion());
        cancelBtn.addActionListener(e -> dispose());

        loadQuestionData();
    }

    private JLabel makeLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        return label;
    }

    private JTextField makeField(Font font) {
        JTextField field = new JTextField();
        field.setFont(font);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return field;
    }

    private JButton makeButton(String text, Color bg, Color fg) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bg);
        button.setForeground(fg);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private void loadQuestionData() {
        try {
            Conn conn = new Conn();
            PreparedStatement pst = conn.c.prepareStatement("SELECT * FROM questions WHERE id = ?");
            pst.setInt(1, questionId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                questionField.setText(rs.getString("question_text"));
                optionAField.setText(rs.getString("option_a"));
                optionBField.setText(rs.getString("option_b"));
                optionCField.setText(rs.getString("option_c"));
                optionDField.setText(rs.getString("option_d"));
                correctAnswerField.setText(rs.getString("correct_answer"));
            } else {
                JOptionPane.showMessageDialog(this, "Question not found.");
                dispose();
            }

            rs.close();
            pst.close();
            conn.c.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading question: " + e.getMessage());
        }
    }

    private void updateQuestion() {
        String question = questionField.getText().trim();
        String a = optionAField.getText().trim();
        String b = optionBField.getText().trim();
        String c = optionCField.getText().trim();
        String d = optionDField.getText().trim();
        String correct = correctAnswerField.getText().trim().toUpperCase();

        if (question.isEmpty() || a.isEmpty() || b.isEmpty() || c.isEmpty() || d.isEmpty() || correct.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.");
            return;
        }

        if (!correct.matches("[ABCD]")) {
            JOptionPane.showMessageDialog(this, "Correct answer must be A, B, C, or D.");
            return;
        }

        try {
            Conn conn = new Conn();
            PreparedStatement pst = conn.c.prepareStatement(
                "UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_answer=? WHERE id=?"
            );
            pst.setString(1, question);
            pst.setString(2, a);
            pst.setString(3, b);
            pst.setString(4, c);
            pst.setString(5, d);
            pst.setString(6, correct);
            pst.setInt(7, questionId);

            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, " Question updated successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "️ Update failed.");
            }

            pst.close();
            conn.c.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating question: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EditQuestionFrame(1).setVisible(true));
    }
}
