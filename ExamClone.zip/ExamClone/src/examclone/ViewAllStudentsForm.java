package examclone;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;

public class ViewAllStudentsForm extends JFrame {

    private JTable studentTable;
    private DefaultTableModel tableModel;

    public ViewAllStudentsForm() {
        setTitle("View All Students");

        // Set frame to full screen
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(false); // you can set true if you want no title bar
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columns = {
            "Reg No", "Name", "Father", "Mother", "DOB",
            "Phone", "Email", "Adhar", "City", "PIN", "State"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        studentTable = new JTable(tableModel);
        studentTable.setAutoCreateRowSorter(true);

        JScrollPane scrollPane = new JScrollPane(studentTable);
        add(scrollPane, BorderLayout.CENTER);

        loadStudentsFromDB();

        setColumnWidths();
    }

    private void loadStudentsFromDB() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        try {
            Conn c = new Conn();
            String query = "SELECT * FROM students";
            ResultSet rs = c.s.executeQuery(query);

            while (rs.next()) {
                String regNo = rs.getString("reg_no");
                String name = rs.getString("name");
                String father = rs.getString("father_name");
                String mother = rs.getString("mother_name");
                Date dob = rs.getDate("dob");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                String adhar = rs.getString("aadhar");
                String city = rs.getString("city");
                String pin = rs.getString("pin_code");
                String state = rs.getString("state");

                tableModel.addRow(new Object[]{
                    regNo, name, father, mother,
                    dob != null ? sdf.format(dob) : "",
                    phone, email, adhar, city, pin, state
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading students: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setColumnWidths() {
        int[] widths = {100, 150, 120, 120, 90, 120, 180, 150, 100, 70, 120};
        for (int i = 0; i < widths.length; i++) {
            TableColumn column = studentTable.getColumnModel().getColumn(i);
            column.setPreferredWidth(widths[i]);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ViewAllStudentsForm().setVisible(true);
        });
    }
}
