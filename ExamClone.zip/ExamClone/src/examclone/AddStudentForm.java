package examclone;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.text.*;
import java.awt.*;
import java.sql.PreparedStatement;
import java.util.Date;

public class AddStudentForm extends JFrame {

    private JTextField regField, nameField, fatherField, motherField, phoneField, emailField,
            aadharField, cityField, pinField;
    private JComboBox<String> stateComboBox;
    private JDateChooser dateChooser;

    public AddStudentForm() {
        setTitle("Add Student - Registration");
        setSize(700, 820);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel headerLabel = new JLabel("Student Registration Form");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        headerLabel.setBounds(180, 20, 400, 40);
        headerLabel.setForeground(new Color(0, 123, 255));
        add(headerLabel);

        int labelX = 60, fieldX = 250, fieldWidth = 350, height = 30, yGap = 50;
        int currentY = 90;

        JLabel regLabel = createLabel("Registration No:");
        regLabel.setBounds(labelX, currentY, 180, height);
        add(regLabel);

        regField = createTextField(generateRegistrationNumber(), false);
        regField.setBounds(fieldX, currentY, fieldWidth, height);
        add(regField);

        currentY += yGap;
        JLabel nameLabel = createLabel("Full Name:");
        nameLabel.setBounds(labelX, currentY, 180, height);
        add(nameLabel);

        nameField = createTextField();
        nameField.setBounds(fieldX, currentY, fieldWidth, height);
        add(nameField);
        addAlphaSpaceFilter(nameField);

        currentY += yGap;
        JLabel fatherLabel = createLabel("Father's Name:");
        fatherLabel.setBounds(labelX, currentY, 180, height);
        add(fatherLabel);

        fatherField = createTextField();
        fatherField.setBounds(fieldX, currentY, fieldWidth, height);
        add(fatherField);
        addAlphaSpaceFilter(fatherField);

        currentY += yGap;
        JLabel motherLabel = createLabel("Mother's Name:");
        motherLabel.setBounds(labelX, currentY, 180, height);
        add(motherLabel);

        motherField = createTextField();
        motherField.setBounds(fieldX, currentY, fieldWidth, height);
        add(motherField);
        addAlphaSpaceFilter(motherField);

        currentY += yGap;
        JLabel dobLabel = createLabel("Date of Birth:");
        dobLabel.setBounds(labelX, currentY, 180, height);
        add(dobLabel);

        dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("yyyy-MM-dd");
        dateChooser.setBounds(fieldX, currentY, fieldWidth, height);
        add(dateChooser);

        currentY += yGap;
        JLabel phoneLabel = createLabel("Phone:");
        phoneLabel.setBounds(labelX, currentY, 180, height);
        add(phoneLabel);

        phoneField = createTextField();
        phoneField.setBounds(fieldX, currentY, fieldWidth, height);
        add(phoneField);
        addNumericFilter(phoneField, 10);

        currentY += yGap;
        JLabel emailLabel = createLabel("Email:");
        emailLabel.setBounds(labelX, currentY, 180, height);
        add(emailLabel);

        emailField = createTextField();
        emailField.setBounds(fieldX, currentY, fieldWidth, height);
        add(emailField);

        currentY += yGap;
        JLabel aadharLabel = createLabel("Aadhar No:");
        aadharLabel.setBounds(labelX, currentY, 180, height);
        add(aadharLabel);

        aadharField = createTextField();
        aadharField.setBounds(fieldX, currentY, fieldWidth, height);
        add(aadharField);
        addNumericFilter(aadharField, 12);

        currentY += yGap;
        JLabel cityLabel = createLabel("City:");
        cityLabel.setBounds(labelX, currentY, 180, height);
        add(cityLabel);

        cityField = createTextField();
        cityField.setBounds(fieldX, currentY, fieldWidth, height);
        add(cityField);
        addAlphaSpaceFilter(cityField);

        currentY += yGap;
        JLabel pinLabel = createLabel("PIN Code:");
        pinLabel.setBounds(labelX, currentY, 180, height);
        add(pinLabel);

        pinField = createTextField();
        pinField.setBounds(fieldX, currentY, fieldWidth, height);
        add(pinField);
        addNumericFilter(pinField, 6);

        currentY += yGap;
        JLabel stateLabel = createLabel("State:");
        stateLabel.setBounds(labelX, currentY, 180, height);
        add(stateLabel);

        String[] states = {
            "Select State", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa",
            "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh",
            "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
            "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
            "Delhi", "Jammu & Kashmir", "Ladakh"
        };
        stateComboBox = new JComboBox<>(states);
        stateComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        stateComboBox.setBounds(fieldX, currentY, fieldWidth, height);
        add(stateComboBox);

        currentY += yGap + 20;
        JButton submitBtn = new JButton("Register");
        submitBtn.setBounds(fieldX + 120, 630, 150, 40);
        submitBtn.setBackground(new Color(40, 167, 69));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        submitBtn.setFocusPainted(false);
        add(submitBtn);

        submitBtn.addActionListener(e -> {
            if (validateFields()) {
                try {
                    Conn c = new Conn();
                    String query = "INSERT INTO students (reg_no, name, father_name, mother_name, dob, phone, email, aadhar, city, pin_code, state) "
                            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    PreparedStatement ps = c.c.prepareStatement(query);
                    ps.setString(1, regField.getText());
                    ps.setString(2, nameField.getText());
                    ps.setString(3, fatherField.getText());
                    ps.setString(4, motherField.getText());

                    Date selectedDate = dateChooser.getDate();
                    java.sql.Date sqlDate = new java.sql.Date(selectedDate.getTime());
                    ps.setDate(5, sqlDate);

                    ps.setString(6, phoneField.getText());
                    ps.setString(7, emailField.getText());
                    ps.setString(8, aadharField.getText());
                    ps.setString(9, cityField.getText());
                    ps.setString(10, pinField.getText());
                    ps.setString(11, (String) stateComboBox.getSelectedItem());

                    int result = ps.executeUpdate();
                    if (result > 0) {
                        JOptionPane.showMessageDialog(this,
                                "Student Registered Successfully!\nRegistration No: " + regField.getText(),
                                "Success", JOptionPane.INFORMATION_MESSAGE);
                        dispose();
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error saving data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        return label;
    }

    private JTextField createTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        field.setBorder(new LineBorder(new Color(200, 200, 200), 1, true));
        return field;
    }

    private JTextField createTextField(String text, boolean editable) {
        JTextField field = createTextField();
        field.setText(text);
        field.setEditable(editable);
        return field;
    }

    private String generateRegistrationNumber() {
        String prefix = "BCA";
        int length = 5;
        StringBuilder sb = new StringBuilder(prefix);
        for (int i = 0; i < length; i++) {
            int digit = (int) (Math.random() * 10);
            sb.append(digit);
        }
        return sb.toString();
    }

    private void addAlphaSpaceFilter(JTextField field) {
        ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string == null) {
                    return;
                }
                if (string.matches("[a-zA-Z\\s]+")) {
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text == null) {
                    return;
                }
                if (text.matches("[a-zA-Z\\s]+")) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    private void addNumericFilter(JTextField field, int maxLength) {
        ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
                if (string == null) {
                    return;
                }
                if (string.matches("\\d+")) {
                    if ((fb.getDocument().getLength() + string.length()) <= maxLength) {
                        super.insertString(fb, offset, string, attr);
                    }
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (text == null) {
                    return;
                }
                if (text.matches("\\d+")) {
                    if ((fb.getDocument().getLength() - length + text.length()) <= maxLength) {
                        super.replace(fb, offset, length, text, attrs);
                    }
                }
            }
        });
    }

    private boolean validateFields() {
        if (nameField.getText().trim().isEmpty()) {
            showError("Please enter the student's full name.");
            return false;
        }
        if (fatherField.getText().trim().isEmpty()) {
            showError("Please enter the father's name.");
            return false;
        }
        if (motherField.getText().trim().isEmpty()) {
            showError("Please enter the mother's name.");
            return false;
        }
        Date selectedDate = dateChooser.getDate();
        if (selectedDate == null) {
            showError("Please select the date of birth.");
            return false;
        }

// Calculate the date 6 years ago
        Date today = new Date();
        long sixYearsInMillis = (long) (6L * 365.25 * 24 * 60 * 60 * 1000);
        Date sixYearsAgo = new Date(today.getTime() - sixYearsInMillis);

        if (!selectedDate.before(sixYearsAgo)) {
            showError("Student must be at least 6 years old.");
            return false;
        }

        if (phoneField.getText().length() != 10) {
            showError("Phone number must be exactly 10 digits.");
            return false;
        }
        if (!emailField.getText().contains("@") || emailField.getText().trim().isEmpty()) {
            showError("Please enter a valid email address.");
            return false;
        }
        if (aadharField.getText().length() != 12) {
            showError("Aadhar number must be exactly 12 digits.");
            return false;
        }
        if (cityField.getText().trim().isEmpty()) {
            showError("Please enter the city.");
            return false;
        }
        if (pinField.getText().length() != 6) {
            showError("PIN code must be exactly 6 digits.");
            return false;
        }
        if (stateComboBox.getSelectedIndex() == 0) {
            showError("Please select a state.");
            return false;
        }
        return true;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AddStudentForm().setVisible(true);
        });
    }
}
