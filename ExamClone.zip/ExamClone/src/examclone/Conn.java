package examclone;


import java.sql.*;  

public class Conn{
    Connection c;
    Statement s;
    public Conn(){  
        try{  
            
            Class.forName("com.mysql.cj.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql:///onlineexam","root","vinay");    
            s =c.createStatement(); 
            
            
           
          
            
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }  
    
     public static void main(String[] args){
                
     }

    PreparedStatement prepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}  
