package examclone;

import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.*;

public class DeleteStudentForm extends JFrame {

    private JTextField searchField;
    private JButton searchButton;

    private JTextField regField, nameField, fatherField, motherField, phoneField, emailField, adharField, cityField, pinField;
    private JDateChooser dobChooser;
    private JComboBox<String> stateCombo;
    private JButton deleteButton;

    public DeleteStudentForm() {
        setTitle("Delete Student Details");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel searchLabel = new JLabel("Enter Registration Number:");
        searchLabel.setBounds(30, 20, 180, 25);
        add(searchLabel);

        searchField = new JTextField();
        searchField.setBounds(220, 20, 200, 25);
        add(searchField);

        searchButton = new JButton("Search");
        searchButton.setBounds(440, 20, 100, 25);
        add(searchButton);

        int labelX = 30, fieldX = 220;
        int yStart = 70, yGap = 40;

        String[] labels = {"Registration Number:", "Name:", "Father's Name:", "Mother's Name:",
                "Date of Birth:", "Phone:", "Email:", "Adhar Number:",
                "City:", "PIN Code:", "State:"};

        JTextField[] fields = {
            regField = new JTextField(), nameField = new JTextField(),
            fatherField = new JTextField(), motherField = new JTextField(),
            phoneField = new JTextField(), emailField = new JTextField(),
            adharField = new JTextField(), cityField = new JTextField(),
            pinField = new JTextField()
        };

        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setBounds(labelX, yStart + i * yGap, 180, 25);
            add(lbl);

            if (i == 4) {
                dobChooser = new JDateChooser();
                dobChooser.setBounds(fieldX, yStart + i * yGap, 320, 25);
                dobChooser.setDateFormatString("dd-MM-yyyy");
                dobChooser.setEnabled(false);
                add(dobChooser);
            } else if (i == 10) {
                String[] states = {"Select State", "Andhra Pradesh", "Bihar", "Delhi", "Goa", "Gujarat",
                        "Haryana", "Karnataka", "Kerala", "Maharashtra", "Punjab", "Rajasthan",
                        "Tamil Nadu", "Uttar Pradesh", "West Bengal"};
                stateCombo = new JComboBox<>(states);
                stateCombo.setBounds(fieldX, yStart + i * yGap, 320, 25);
                stateCombo.setEnabled(false);
                add(stateCombo);
            } else {
                fields[i < 4 ? i : i - 1].setBounds(fieldX, yStart + i * yGap, 320, 25);
                fields[i < 4 ? i : i - 1].setEditable(false);
                add(fields[i < 4 ? i : i - 1]);
            }
        }

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(fieldX, yStart + 11 * yGap + 10, 150, 35);
        deleteButton.setEnabled(false);
        add(deleteButton);

        searchButton.addActionListener(e -> searchStudent());
        deleteButton.addActionListener(e -> deleteStudent());
    }

    private void clearForm() {
        regField.setText("");
        nameField.setText("");
        fatherField.setText("");
        motherField.setText("");
        dobChooser.setDate(null);
        phoneField.setText("");
        emailField.setText("");
        adharField.setText("");
        cityField.setText("");
        pinField.setText("");
        stateCombo.setSelectedIndex(0);
    }

    private void populateForm(ResultSet rs) throws Exception {
        regField.setText(rs.getString("reg_no"));
        nameField.setText(rs.getString("name"));
        fatherField.setText(rs.getString("father_name"));
        motherField.setText(rs.getString("mother_name"));
        dobChooser.setDate(rs.getDate("dob"));
        phoneField.setText(rs.getString("phone"));
        emailField.setText(rs.getString("email"));
        adharField.setText(rs.getString("aadhar"));
        cityField.setText(rs.getString("city"));
        pinField.setText(rs.getString("pin_code"));
        stateCombo.setSelectedItem(rs.getString("state"));
    }

    private void searchStudent() {
        String regNo = searchField.getText().trim();
        if (regNo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a registration number", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Conn conn = new Conn();
            String query = "SELECT * FROM students WHERE reg_no = ?";
            PreparedStatement ps = conn.c.prepareStatement(query);
            ps.setString(1, regNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                populateForm(rs);
                deleteButton.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Student not found!", "Error", JOptionPane.ERROR_MESSAGE);
                clearForm();
                deleteButton.setEnabled(false);
            }

            rs.close();
            ps.close();
            conn.c.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching student data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteStudent() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this student record?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                Conn conn = new Conn();
                String query = "DELETE FROM students WHERE reg_no = ?";
                PreparedStatement ps = conn.c.prepareStatement(query);
                ps.setString(1, regField.getText());
                int rows = ps.executeUpdate();

                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Student record deleted successfully!", "Deleted", JOptionPane.INFORMATION_MESSAGE);
                    clearForm();
                    deleteButton.setEnabled(false);
                } else {
                    JOptionPane.showMessageDialog(this, "Deletion failed!", "Error", JOptionPane.ERROR_MESSAGE);
                }

                ps.close();
                conn.c.close();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting student.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DeleteStudentForm().setVisible(true);
        });
    }
}
