package examclone;

import javax.swing.*;
import java.awt.*;
import java.sql.PreparedStatement;

public class AddQuestionsFrame extends JFrame {

    private JLabel examCodeLabel, questionCountLabel;
    private JTextArea questionArea;
    private JTextField optAField, optBField, optCField, optDField;
    private JComboBox<String> correctAnswerBox;
    private JButton nextBtn, submitBtn;

    private String examCode, subject;
    private int time, fullMarks, totalQuestions;
    private float marksPerQ, negativeMark;
    private int currentQuestion = 1;

    public AddQuestionsFrame(String examCode, String subject, int time, float marksPerQ, float negativeMark, int fullMarks, int totalQuestions) {
        this.examCode = examCode;
        this.subject = subject;
        this.time = time;
        this.marksPerQ = marksPerQ;
        this.negativeMark = negativeMark;
        this.fullMarks = fullMarks;
        this.totalQuestions = totalQuestions;

        setTitle("Add Questions - Exam: " + examCode);
        setSize(700, 600);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(230, 245, 255)); // light blue background

        // Header
        JLabel header = new JLabel("Add MCQ Questions");
        header.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.setForeground(new Color(10, 90, 170)); // dark blue
        header.setBounds(230, 20, 300, 30);
        add(header);

        // Exam info
        examCodeLabel = new JLabel("Exam Code: " + examCode + " | Subject: " + subject);
        examCodeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        examCodeLabel.setForeground(new Color(50, 50, 50));
        examCodeLabel.setBounds(50, 60, 600, 30);
        add(examCodeLabel);

        questionCountLabel = new JLabel("Question " + currentQuestion + " of " + totalQuestions);
        questionCountLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        questionCountLabel.setForeground(new Color(10, 90, 170));
        questionCountLabel.setBounds(50, 90, 300, 30);
        add(questionCountLabel);

        // Question label and area
        JLabel questionLabel = new JLabel("Question:");
        questionLabel.setBounds(50, 130, 100, 30);
        questionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        questionLabel.setForeground(new Color(30, 30, 30));
        add(questionLabel);

        questionArea = new JTextArea();
        questionArea.setLineWrap(true);
        questionArea.setWrapStyleWord(true);
        questionArea.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        questionArea.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180)));
        JScrollPane scrollPane = new JScrollPane(questionArea);
        scrollPane.setBounds(150, 130, 480, 80);
        add(scrollPane);

        // Options
        addOptionField("Option A:", 230, optAField = new JTextField());
        addOptionField("Option B:", 270, optBField = new JTextField());
        addOptionField("Option C:", 310, optCField = new JTextField());
        addOptionField("Option D:", 350, optDField = new JTextField());

        // Correct answer
        JLabel correctLabel = new JLabel("Correct Answer:");
        correctLabel.setBounds(50, 390, 130, 30);
        correctLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        correctLabel.setForeground(new Color(30, 30, 30));
        add(correctLabel);

        correctAnswerBox = new JComboBox<>(new String[]{"A", "B", "C", "D"});
        correctAnswerBox.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        correctAnswerBox.setBounds(190, 390, 80, 30);
        correctAnswerBox.setBackground(Color.WHITE);
        add(correctAnswerBox);

        // Buttons
        nextBtn = new JButton("Next Question");
        nextBtn.setBounds(180, 460, 150, 40);
        nextBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        nextBtn.setBackground(new Color(0, 123, 85)); // nice green
        nextBtn.setForeground(Color.WHITE);
        nextBtn.setFocusPainted(false);
        add(nextBtn);

        submitBtn = new JButton("Submit All");
        submitBtn.setBounds(360, 460, 150, 40);
        submitBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        submitBtn.setBackground(new Color(0, 102, 204)); // nice blue
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFocusPainted(false);
        submitBtn.setEnabled(false);
        add(submitBtn);

        nextBtn.addActionListener(e -> handleNextQuestion());
        submitBtn.addActionListener(e -> handleSubmitAll());
    }

    private void addOptionField(String label, int y, JTextField field) {
        JLabel optLabel = new JLabel(label);
        optLabel.setBounds(50, y, 100, 30);
        optLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        optLabel.setForeground(new Color(30, 30, 30));
        add(optLabel);

        field.setBounds(150, y, 480, 30);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        field.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180)));
        add(field);
    }

    private void handleNextQuestion() {
        if (!validateFields()) return;

        saveQuestionToDB();  // Save the current question

        clearFields();
        currentQuestion++;

        if (currentQuestion <= totalQuestions) {
            questionCountLabel.setText("Question " + currentQuestion + " of " + totalQuestions);
           
            if (currentQuestion == totalQuestions) {
                nextBtn.setEnabled(false);
                submitBtn.setEnabled(true);
            }
        }
    }

    private void handleSubmitAll() {
        
        saveQuestionToDB();  // Save the current question

        clearFields();
        JOptionPane.showMessageDialog(this, "✅ All questions submitted successfully!", "Done", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }

    private void clearFields() {
        questionArea.setText("");
        optAField.setText("");
        optBField.setText("");
        optCField.setText("");
        optDField.setText("");
        correctAnswerBox.setSelectedIndex(0);
    }

    private boolean validateFields() {
        if (questionArea.getText().trim().isEmpty() || optAField.getText().trim().isEmpty() ||
            optBField.getText().trim().isEmpty() || optCField.getText().trim().isEmpty() ||
            optDField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields", "Validation", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void saveQuestionToDB() {
       
        try {
            Conn c = new Conn();
            String sql = "INSERT INTO questions (exam_code, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = c.c.prepareStatement(sql);

            ps.setString(1, examCode);
            ps.setString(2, questionArea.getText().trim());
            ps.setString(3, optAField.getText().trim());
            ps.setString(4, optBField.getText().trim());
            ps.setString(5, optCField.getText().trim());
            ps.setString(6, optDField.getText().trim());
            ps.setString(7, (String) correctAnswerBox.getSelectedItem());

            ps.executeUpdate();

            ps.close();
            

            System.out.println("Question " + currentQuestion + " saved to database.");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving question: " + e.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
