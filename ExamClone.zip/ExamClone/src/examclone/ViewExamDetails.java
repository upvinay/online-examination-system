package examclone;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.table.DefaultTableCellRenderer;

public class ViewExamDetails extends JFrame {

    private JTable table;
    private DefaultTableModel tableModel;

    public ViewExamDetails() {
        setTitle("View All Students");

        // Set frame to full screen
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(false); // you can set true if you want no title bar
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columns = {
            "Exam Code", "Subject Name", "Exam Duration", "Marks Per Question ", "Negative Marks/Q.",
            "Full Marks", "Total Number Of Q. "
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

           
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadStudentsFromDB();

        setColumnWidths();
    }

    private void loadStudentsFromDB() {
       

        try {
            Conn c = new Conn();
            String query = "SELECT * FROM exams";
            ResultSet rs = c.s.executeQuery(query);

            while (rs.next()) {
                String ExamCode = rs.getString("exam_code");
                String subject = rs.getString("subject");
                String duration = rs.getString("duration");
                String marksp = rs.getString("marks_per_question");
                String marksn = rs.getString("negative_marking");
                String fullmark = rs.getString("full_marks");
                String totalq= rs.getString("total_questions");
                
               

                tableModel.addRow(new Object[]{
                    ExamCode, subject, duration, marksp,
                    
                    marksn, fullmark, totalq
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading students: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setColumnWidths() {
        int[] widths = {100, 150, 120, 120, 90, 120, 180};
        for (int i = 0; i < widths.length; i++) {
            TableColumn column = table.getColumnModel().getColumn(i);
            column.setPreferredWidth(widths[i]);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ViewExamDetails().setVisible(true);
        });
    }
}
