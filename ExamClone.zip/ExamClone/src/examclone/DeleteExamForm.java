package examclone;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DeleteExamForm extends JFrame {

    private JTextField codeField, subjectField, timeField, fullMarksField, perQuesField, minusMarkField, totalQuesField;
    private JButton searchBtn, deleteBtn;
    private JPanel detailsPanel;

    public DeleteExamForm() {
        setTitle("️ Delete Exam by Code");
        setSize(550, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(245, 245, 255));

        JLabel heading = new JLabel("Delete Scheduled Exam", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        heading.setBounds(100, 20, 350, 30);
        add(heading);

        JLabel codeLabel = new JLabel("Enter Exam Code:");
        codeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        codeLabel.setBounds(50, 70, 150, 25);
        add(codeLabel);

        codeField = new JTextField();
        codeField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        codeField.setBounds(200, 70, 200, 25);
        add(codeField);

        searchBtn = new JButton(" Search");
        searchBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        searchBtn.setBackground(new Color(100, 149, 237));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setBounds(410, 70, 100, 25);
        add(searchBtn);

        // Details Panel
        detailsPanel = new JPanel();
        detailsPanel.setLayout(new GridLayout(6, 2, 10, 10));
        detailsPanel.setBounds(50, 120, 420, 200);
        detailsPanel.setBackground(new Color(250, 250, 255));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Exam Details"));
        add(detailsPanel);
        detailsPanel.setVisible(false);

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 15);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);

        subjectField = createField("Subject:", labelFont, fieldFont);
        timeField = createField("Time (mins):", labelFont, fieldFont);
        fullMarksField = createField("Full Marks:", labelFont, fieldFont);
        perQuesField = createField("Marks per Question:", labelFont, fieldFont);
        minusMarkField = createField("Negative Marking:", labelFont, fieldFont);
        totalQuesField = createField("Total Questions:", labelFont, fieldFont);

        // Delete Button
        deleteBtn = new JButton(" Delete This Exam");
        deleteBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        deleteBtn.setBackground(new Color(220, 20, 60));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setBounds(170, 340, 200, 40);
        deleteBtn.setVisible(false);
        add(deleteBtn);

        // Action Listeners
        searchBtn.addActionListener(e -> searchExam());
        deleteBtn.addActionListener(e -> deleteExam());
    }

    private JTextField createField(String label, Font labelFont, Font fieldFont) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(labelFont);
        JTextField txt = new JTextField();
        txt.setFont(fieldFont);
        txt.setEditable(false);
        detailsPanel.add(lbl);
        detailsPanel.add(txt);
        return txt;
    }

    private void searchExam() {
        String examCode = codeField.getText().trim();

        if (examCode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an exam code.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Conn c = new Conn();
            String sql = "SELECT * FROM exams WHERE exam_code = ?";
            PreparedStatement pst = c.c.prepareStatement(sql);
            pst.setString(1, examCode);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                subjectField.setText(rs.getString("subject"));
                timeField.setText(String.valueOf(rs.getInt("duration")));
                fullMarksField.setText(String.valueOf(rs.getInt("full_marks")));
                perQuesField.setText(String.valueOf(rs.getFloat("marks_per_question")));
                minusMarkField.setText(String.valueOf(rs.getFloat("negative_marking")));
                totalQuesField.setText(String.valueOf(rs.getInt("total_questions")));

                detailsPanel.setVisible(true);
                deleteBtn.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, " No Exam found with that code!", "Not Found", JOptionPane.ERROR_MESSAGE);
                detailsPanel.setVisible(false);
                deleteBtn.setVisible(false);
            }

            rs.close();
            pst.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void deleteExam() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this exam?",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            String examCode = codeField.getText().trim();
            try {
                Conn c = new Conn();

                // Delete questions linked to exam if exists
                String delQuestionsSql = "DELETE FROM questions WHERE exam_code = ?";
                PreparedStatement pstQ = c.c.prepareStatement(delQuestionsSql);
                pstQ.setString(1, examCode);
                pstQ.executeUpdate();
                pstQ.close();

                // Delete exam
                String delExamSql = "DELETE FROM exams WHERE exam_code = ?";
                PreparedStatement pst = c.c.prepareStatement(delExamSql);
                pst.setString(1, examCode);
                int affected = pst.executeUpdate();
                pst.close();

                if (affected > 0) {
                    JOptionPane.showMessageDialog(this, " Exam deleted successfully!", "Deleted", JOptionPane.INFORMATION_MESSAGE);
                    
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, " Exam not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DeleteExamForm().setVisible(true));
    }
}
