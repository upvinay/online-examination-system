package examclone;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ViewAllResultsFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;

    public ViewAllResultsFrame() {
        super(" All Exam Results");

        // Full screen setup
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Font uiFont = new Font("Segoe UI", Font.PLAIN, 16);

        // Title panel
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(33, 150, 243));
        titlePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel titleLabel = new JLabel(" ALL   EXAM   RESULTS", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 32));
        titleLabel.setForeground(Color.white);
        titlePanel.add(titleLabel, BorderLayout.CENTER);

        // Column headers
        String[] columns = {"Reg No", "Exam Code", "Total Questions", "Attempted", "Correct", "Wrong", "Not Attempted", "Score", "Full Marks"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Table design
        table = new JTable(model);
        table.setFont(uiFont);
        table.setRowHeight(32);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setShowHorizontalLines(false);
        table.setShowVerticalLines(false);

        // Header style
        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(25, 118, 210));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 18));
        header.setReorderingAllowed(false);

        // Row colors
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private final Color evenColor = new Color(245, 250, 255);
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, col);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? evenColor : Color.WHITE);
                } else {
                    c.setBackground(new Color(179, 229, 252));
                }
                setBorder(noFocusBorder);
                return c;
            }
        });

        // Scroll pane with border radius effect
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        scrollPane.getViewport().setBackground(Color.WHITE);

        // Refresh button design
        JButton refreshBtn = new JButton(" Refresh");
        refreshBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        refreshBtn.setBackground(new Color(0, 172, 193));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        refreshBtn.setFocusPainted(false);
        refreshBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 151, 167)),
                new EmptyBorder(10, 30, 10, 30)
        ));
        refreshBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                refreshBtn.setBackground(new Color(0, 188, 212));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                refreshBtn.setBackground(new Color(0, 172, 193));
            }
        });
        refreshBtn.addActionListener(e -> loadResultsFromDatabase());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(refreshBtn);

        // Combine all
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        add(mainPanel);
        loadResultsFromDatabase();
    }

    private void loadResultsFromDatabase() {
        try {
            Conn conn = new Conn();

            String sql = "SELECT reg_no, exam_code, total_questions, attempted, correct, wrong, not_attempted, score, full_marks FROM results";
            PreparedStatement pst = conn.c.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            model.setRowCount(0);

            while (rs.next()) {
                Object[] row = {
                        rs.getString("reg_no"),
                        rs.getString("exam_code"),
                        rs.getInt("total_questions"),
                        rs.getInt("attempted"),
                        rs.getInt("correct"),
                        rs.getInt("wrong"),
                        rs.getInt("not_attempted"),
                        rs.getFloat("score"),
                        rs.getFloat("full_marks")
                };
                model.addRow(row);
            }

            rs.close();
            pst.close();
            conn.c.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, " Error fetching results from database:\n" + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewAllResultsFrame().setVisible(true));
    }
}
