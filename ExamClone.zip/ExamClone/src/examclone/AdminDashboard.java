package examclone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminDashboard extends JFrame {

    private JPanel contentPanel;

    public AdminDashboard() {
        super("Admin Dashboard - Online Examination System");

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(false);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Header Panel
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(25, 25, 112));
        header.setPreferredSize(new Dimension(900, 60));

        JLabel titleLabel = new JLabel("  Welcome, Admin");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.add(titleLabel, BorderLayout.WEST);

        ImageIcon logoutIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/Logout.png"));
        Image logoutImg = logoutIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        logoutIcon = new ImageIcon(logoutImg);

        JButton logoutBtn = new JButton(" Log Out", logoutIcon);
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logoutBtn.setBackground(Color.DARK_GRAY);
        logoutBtn.setForeground(Color.RED);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.setPreferredSize(new Dimension(180, 40));
        logoutBtn.setHorizontalAlignment(SwingConstants.CENTER);
        header.add(logoutBtn, BorderLayout.EAST);

        logoutBtn.addActionListener(e -> {
            dispose();
            new StartPage().setVisible(true);
        });

        add(header, BorderLayout.NORTH);

        // Sidebar Menu
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new GridLayout(6, 1, 10, 10));
        sidebar.setBackground(new Color(240, 248, 255));
        sidebar.setPreferredSize(new Dimension(220, getHeight()));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));

        String[] menuItems = {
            "Dashboard", "Manage Students", "Manage Exams", "Results", "Settings", "Support"
        };

        for (String item : menuItems) {
            JButton btn = new JButton(item);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setHorizontalAlignment(SwingConstants.CENTER);
            btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
            btn.setBackground(new Color(72, 61, 139));
            btn.setContentAreaFilled(false);
            btn.setOpaque(true);

            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(new Color(123, 104, 238));
                }

                public void mouseExited(MouseEvent e) {
                    btn.setBackground(new Color(72, 61, 139));
                }
            });

            btn.addActionListener(e -> {
                switch (btn.getText()) {
                    case "Support":
                        showSupportPanel();
                        break;
                    case "Manage Students":
                        showManageStudentsPanel();
                        break;
                    case "Manage Exams":
                        showManageExamsPanel();
                        break;
                    case "Results":
                        showResultsPanel();
                        break;
                    case "Settings":
                        showSettingsPanel();
                        break;
                    case "Dashboard":
                        showDashboardPanel();
                        break;
                    default:
                        showDefaultPanel("You selected: " + btn.getText());
                }
            });

            sidebar.add(btn);
        }

        add(sidebar, BorderLayout.WEST);

        // Main Content Panel
        contentPanel = new JPanel();
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(72, 61, 139), 2, true),
                "Content",
                javax.swing.border.TitledBorder.RIGHT,
                javax.swing.border.TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 18),
                new Color(72, 61, 139)
        ));

        JLabel welcomeText = new JLabel("Select an option from the left menu", SwingConstants.CENTER);
        welcomeText.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        contentPanel.add(welcomeText, BorderLayout.CENTER);

        add(contentPanel, BorderLayout.CENTER);
    }

    private void showDefaultPanel(String text) {
        contentPanel.removeAll();

        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        contentPanel.add(label, BorderLayout.CENTER);
        
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showManageStudentsPanel() {
        contentPanel.removeAll();

        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/managestudent1.jpg"));
        Image bgImage = bgIcon.getImage();

        ImageBackgroundPanel backgroundPanel = new ImageBackgroundPanel(bgImage);
        backgroundPanel.setLayout(new BorderLayout());

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(40, 10, 40, 30));

        Font btnFont = new Font("Segoe UI", Font.BOLD, 18);

        JButton addBtn = new JButton("   Add Student   ");
        styleButton(addBtn, btnFont);
        addBtn.setForeground(Color.BLACK);
        addBtn.setBackground(new Color(250, 213, 165));

        JButton updateBtn = new JButton("Update Student");
        styleButton(updateBtn, btnFont);
        updateBtn.setForeground(Color.BLACK);
        updateBtn.setBackground(new Color(250, 213, 165));

        JButton viewBtn = new JButton("   View Student  ");
        styleButton(viewBtn, btnFont);
        viewBtn.setForeground(Color.BLACK);
        viewBtn.setBackground(new Color(250, 213, 165));

        JButton deleteBtn = new JButton(" Delete Student ");
        styleButton(deleteBtn, btnFont);
        deleteBtn.setForeground(Color.BLACK);
        deleteBtn.setBackground(new Color(250, 213, 165));

        rightPanel.add(addBtn);
        rightPanel.add(Box.createVerticalStrut(20));
        rightPanel.add(updateBtn);
        rightPanel.add(Box.createVerticalStrut(20));
        rightPanel.add(viewBtn);
        rightPanel.add(Box.createVerticalStrut(20));
        rightPanel.add(deleteBtn);

        backgroundPanel.add(rightPanel, BorderLayout.EAST);

        contentPanel.add(backgroundPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();

        addBtn.addActionListener(e -> new AddStudentForm().setVisible(true));
        updateBtn.addActionListener(e -> new UpdateStudentForm().setVisible(true));
        viewBtn.addActionListener(e -> new ViewAllStudentsForm().setVisible(true));
        deleteBtn.addActionListener(e -> new DeleteStudentForm().setVisible(true));

    }

    private void showManageExamsPanel() {
        contentPanel.removeAll();

        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/managexam.jpg"));
        Image bgImage = bgIcon.getImage();

        ImageBackgroundPanel backgroundPanel = new ImageBackgroundPanel(bgImage);
        backgroundPanel.setLayout(new BorderLayout());

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(40, 10, 40, 850));

        Font btnFont = new Font("Segoe UI", Font.BOLD, 18);

        JButton scheduleBtn = new JButton(" Schedule Exam ");
        styleButton(scheduleBtn, btnFont);
        scheduleBtn.setForeground(Color.BLACK);
        scheduleBtn.setBackground(new Color(250, 213, 165));

        JButton deleteBtn = new JButton("   Delete  Exam   ");
        styleButton(deleteBtn, btnFont);
        deleteBtn.setForeground(Color.BLACK);
        deleteBtn.setBackground(new Color(250, 213, 165));

        JButton vBtn = new JButton("    View  Exams   ");
        styleButton(vBtn, btnFont);
        vBtn.setForeground(Color.BLACK);
        vBtn.setBackground(new Color(250, 213, 165));

        JButton manageQBtn = new JButton(" Manage - Ques ");
        styleButton(manageQBtn, btnFont);
        manageQBtn.setForeground(Color.BLACK);
        manageQBtn.setBackground(new Color(250, 213, 165));

        rightPanel.add(scheduleBtn);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(deleteBtn);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(vBtn);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(manageQBtn);

        backgroundPanel.add(rightPanel, BorderLayout.EAST);

        scheduleBtn.addActionListener(e -> {
            new ScheduleExamFrame().setVisible(true);
        });

        deleteBtn.addActionListener(e -> {
            new DeleteExamForm().setVisible(true);
        });

        vBtn.addActionListener(e -> {
            new ViewExamDetails().setVisible(true);
        });

        manageQBtn.addActionListener(e -> {
            new ViewQuestionsFrame().setVisible(true); // You can change the frame class as needed
        });

        contentPanel.add(backgroundPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showResultsPanel() {
        contentPanel.removeAll();

        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/resultbg.jpg")); // Add results.jpg to your icon folder
        Image bgImage = bgIcon.getImage();

        ImageBackgroundPanel backgroundPanel = new ImageBackgroundPanel(bgImage);
        backgroundPanel.setLayout(new BorderLayout());

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(40, 10, 140, 30));

        Font btnFont = new Font("Segoe UI", Font.BOLD, 18);

        JButton viewResultsBtn = new JButton(" View All Results ");
        styleButton(viewResultsBtn, btnFont);
        viewResultsBtn.setForeground(Color.BLACK);
        viewResultsBtn.setBackground(new Color(250, 213, 165));

        JButton searchStudentBtn = new JButton("    By STUDENT    ");
        styleButton(searchStudentBtn, btnFont);
        searchStudentBtn.setForeground(Color.BLACK);
        searchStudentBtn.setBackground(new Color(250, 213, 165));

        rightPanel.add(viewResultsBtn);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(searchStudentBtn);

        backgroundPanel.add(rightPanel, BorderLayout.WEST);
        viewResultsBtn.addActionListener(e -> new ViewAllResultsFrame().setVisible(true));
        searchStudentBtn.addActionListener(e -> new ScorecardFrame().setVisible(true));

        contentPanel.add(backgroundPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showSettingsPanel() {
        contentPanel.removeAll();

        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/setting.png")); // Add results.jpg to your icon folder
        Image bgImage = bgIcon.getImage();

        ImageBackgroundPanel backgroundPanel = new ImageBackgroundPanel(bgImage);
        backgroundPanel.setLayout(new BorderLayout());

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(40, 10, 140, 30));

        Font btnFont = new Font("Segoe UI", Font.BOLD, 18);

        JButton approveBtn = new JButton("Approve Student");
        styleButton(approveBtn, btnFont);
        approveBtn.setForeground(Color.BLACK);
        approveBtn.setBackground(Color.green);

        JButton addAdmin = new JButton("Add New Admin ");
        styleButton(addAdmin, btnFont);
        addAdmin.setForeground(Color.BLACK);
        addAdmin.setBackground(Color.magenta);

        rightPanel.add(approveBtn);
        rightPanel.add(Box.createVerticalStrut(15));
        rightPanel.add(addAdmin);

        backgroundPanel.add(rightPanel, BorderLayout.WEST);

        addAdmin.addActionListener(e -> {
            new AdminRegisterFrame().setVisible(true);
        });

        approveBtn.addActionListener(e -> {
            new ApproveStudentFrame().setVisible(true);
        });

        contentPanel.add(backgroundPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showDashboardPanel() {
        contentPanel.removeAll();

        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("examclone/icon/sy.png")); // Add results.jpg to your icon folder
        Image bgImage = bgIcon.getImage();

        ImageBackgroundPanel backgroundPanel = new ImageBackgroundPanel(bgImage);
        backgroundPanel.setLayout(new BorderLayout());

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(40, 10, 140, 30));

        
        JLabel bLabel = new JLabel("  This is the Dashboard ");
        bLabel.setForeground(Color.WHITE);
        bLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        bLabel.setBounds(280,120, 700, 35);

        
        
        
        rightPanel.add(bLabel);

        backgroundPanel.add(rightPanel, BorderLayout.WEST);

       

        contentPanel.add(backgroundPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void showSupportPanel() {
        contentPanel.removeAll();

        JPanel supportPanel = new JPanel();
        supportPanel.setLayout(new BoxLayout(supportPanel, BoxLayout.Y_AXIS));
        supportPanel.setBackground(Color.WHITE);
        supportPanel.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));

        JLabel heading = new JLabel("📞 Support & Help");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 32));
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        heading.setForeground(new Color(25, 25, 112));

        JTextArea info = new JTextArea(
                "\nFor any issues or help, please contact us:\n\n"
                + "📧 Email: upvinay101@gmail.com\n"
                + "📞 Phone: +91-9835792692 (Mon–Fri, 10AM–6PM)\n\n"
                + "📘 Instagram: @vinay.up0\n"
                + "🛠️ Version: 1.0.0\n\n"
                + "We’re here to assist you anytime!"
        );
        info.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        info.setEditable(false);
        info.setOpaque(false);
        info.setAlignmentX(Component.LEFT_ALIGNMENT);

        supportPanel.add(heading);
        supportPanel.add(Box.createVerticalStrut(20));
        supportPanel.add(info);

        contentPanel.add(supportPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private void styleButton(JButton button, Font font) {
        button.setFont(font);
        button.setBackground(new Color(72, 61, 139));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(180, 50));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    class ImageBackgroundPanel extends JPanel {

        private Image backgroundImage;

        public ImageBackgroundPanel(Image backgroundImage) {
            this.backgroundImage = backgroundImage;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminDashboard().setVisible(true));
    }
}
