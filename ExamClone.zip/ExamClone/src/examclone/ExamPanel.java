package examclone;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;

public class ExamPanel extends JFrame {

    private String name, regNo, examCode, subject;
    private int currentQuestionIndex = 0;
    private int examDurationSeconds;

    private String[] questions;           // Loaded from DB
    private String[][] options;           // Loaded from DB

    private int[] selectedAnswers;
    private boolean[] markedForReview;

    private JLabel lblTimer;
    private JLabel lblQuestion;
    private JRadioButton[] optionButtons = new JRadioButton[4];
    private ButtonGroup optionGroup = new ButtonGroup();
    private JButton[] paletteButtons;
    private JButton btnSaveNext, btnClear, btnMarkReviewNext;

    public ExamPanel(String regNo, String name, String examCode, String subject) {
        this.name = name;
        this.regNo = regNo;
        this.examCode = examCode;
        this.subject = subject;

        // Fetch questions and options from DB
         this.examDurationSeconds = getExamDurationSeconds(examCode);
        fetchQuestionsFromDB();
        try {
            Conn conn = new Conn();

            String checkSQL = "DELETE FROM student_answers WHERE reg_no = ? AND exam_code = ?";
            PreparedStatement checkStmt = conn.c.prepareStatement(checkSQL);
            checkStmt.setString(1, regNo);       // actual variable
            checkStmt.setString(2, examCode);    // actual variable

            int rowsDeleted = checkStmt.executeUpdate(); // execute the delete

            System.out.println(rowsDeleted + " existing answer(s) deleted.");

        } catch (Exception e) {
            e.printStackTrace();
        }

        selectedAnswers = new int[questions.length];
        Arrays.fill(selectedAnswers, -1);
        markedForReview = new boolean[questions.length];
        paletteButtons = new JButton[questions.length];

        setTitle("NTA Online Exam Simulator");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);
        setUndecorated(true); // Removes title bar (no close/minimize buttons)


        createHeader();
        createInfoPanel();
        createCenter();
        createRightPalette();
        createFooter();

        loadQuestion();
        startTimer();

        setVisible(true);
    }

    private void fetchQuestionsFromDB() {
        ArrayList<QuestionEntry> entries = new ArrayList<>();

        try {
            Conn conn = new Conn();
            String sql = "SELECT question_text, option_a, option_b, option_c, option_d, correct_answer FROM questions WHERE exam_code = ?";

            PreparedStatement ps = conn.c.prepareStatement(sql);
            ps.setString(1, examCode);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String q = rs.getString("question_text");
                String[] opts = new String[]{
                    rs.getString("option_a"),
                    rs.getString("option_b"),
                    rs.getString("option_c"),
                    rs.getString("option_d")
                };
                char correct = rs.getString("correct_answer").toLowerCase().charAt(0); // Ensures 'A'/'B' becomes 'a'/'b'
                entries.add(new QuestionEntry(q, opts));
            }

            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error loading questions from database.\n" + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        // 🔀 Shuffle entries randomly
        java.util.Collections.shuffle(entries);

        // Extract shuffled questions and options into arrays
        questions = new String[entries.size()];
        options = new String[entries.size()][4];

        for (int i = 0; i < entries.size(); i++) {
            questions[i] = entries.get(i).question;
            options[i] = entries.get(i).options;
        }
    }

    class QuestionEntry {

        String question;
        String[] options;

        QuestionEntry(String question, String[] options) {
            this.question = question;
            this.options = options;

        }
    }

    private void createHeader() {
        JPanel header = new JPanel();
        header.setPreferredSize(new Dimension(getWidth(), 50));
        header.setBackground(new Color(33, 37, 41));
        header.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 12));

        JLabel lblTitle = new JLabel("NTA Online Exam Simulator");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));

        header.add(lblTitle);

        add(header, BorderLayout.NORTH);
    }

    private void createInfoPanel() {
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBorder(new MatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
        infoPanel.setBackground(new Color(245, 245, 245));
        infoPanel.setPreferredSize(new Dimension(getWidth(), 50));

        // Left side info (Name, Reg No, Exam Code, Subject)
        JLabel lblInfo = new JLabel(String.format("Name: %s | Reg No: %s | Exam Code: %s | Subject: %s",
                name, regNo, examCode, subject));
        lblInfo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblInfo.setBorder(new EmptyBorder(10, 20, 10, 10));
        lblInfo.setForeground(new Color(33, 37, 41));

        // Right side timer label
        lblTimer = new JLabel("Time Left: ");
        lblTimer.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTimer.setForeground(new Color(220, 20, 60)); // Crimson red
        lblTimer.setBorder(new EmptyBorder(10, 10, 10, 20));

        infoPanel.add(lblInfo, BorderLayout.WEST);
        infoPanel.add(lblTimer, BorderLayout.EAST);

        add(infoPanel, BorderLayout.BEFORE_FIRST_LINE);
    }

    private void createCenter() {
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(25, 30, 25, 30));
        centerPanel.setBackground(Color.WHITE);

        lblQuestion = new JLabel("Question");
        lblQuestion.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblQuestion.setBorder(new EmptyBorder(0, 0, 20, 0));
        lblQuestion.setForeground(new Color(33, 37, 41));
        centerPanel.add(lblQuestion, BorderLayout.NORTH);

        JPanel optionsPanel = new JPanel(new GridLayout(4, 1, 15, 15));
        optionsPanel.setBackground(Color.WHITE);
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton();
            optionButtons[i].setFont(new Font("Segoe UI", Font.PLAIN, 19));
            optionButtons[i].setBackground(Color.WHITE);
            optionButtons[i].setFocusPainted(false);
            optionGroup.add(optionButtons[i]);
            optionsPanel.add(optionButtons[i]);
        }
        centerPanel.add(optionsPanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);
    }

    private void createRightPalette() {
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setPreferredSize(new Dimension(220, getHeight()));
        rightPanel.setBackground(new Color(250, 250, 250));
        rightPanel.setBorder(new MatteBorder(0, 1, 0, 0, Color.GRAY));

        JLabel lblPalette = new JLabel("Question Palette");
        lblPalette.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblPalette.setBorder(new EmptyBorder(15, 15, 12, 15));
        lblPalette.setForeground(new Color(33, 37, 41));
        rightPanel.add(lblPalette, BorderLayout.NORTH);

        JPanel paletteGrid = new JPanel();
        paletteGrid.setLayout(new GridLayout(0, 3, 8, 8));
        paletteGrid.setBorder(new EmptyBorder(10, 12, 10, 12));
        paletteGrid.setBackground(new Color(250, 250, 250));

        for (int i = 0; i < questions.length; i++) {
            JButton btn = new JButton(String.valueOf(i + 1));
            btn.setFont(new Font("Segoe UI", Font.BOLD, 10));
            btn.setBackground(Color.LIGHT_GRAY);
            btn.setFocusPainted(false);
            btn.setPreferredSize(new Dimension(50, 50));
            int idx = i;
            btn.addActionListener(e -> {
                saveAnswer();
                currentQuestionIndex = idx;
                loadQuestion();
            });
            paletteButtons[i] = btn;
            paletteGrid.add(btn);
        }

        JScrollPane scrollPane = new JScrollPane(paletteGrid);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);
        rightPanel.add(scrollPane, BorderLayout.CENTER);

        add(rightPanel, BorderLayout.EAST);
    }

    private void createFooter() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 22, 15));
        footer.setBackground(Color.WHITE);

        btnSaveNext = new JButton("Save & Next");
        btnClear = new JButton("CLEAR");
        btnMarkReviewNext = new JButton("Mark For Review");

        styleButton(btnSaveNext, new Color(0, 153, 76), Color.WHITE);
        styleButton(btnClear, Color.DARK_GRAY, Color.WHITE);
        btnClear.setBorder(new LineBorder(new Color(180, 180, 180)));
        styleButton(btnMarkReviewNext, new Color(255, 153, 0), Color.WHITE);

        btnSaveNext.addActionListener(e -> {
            saveAnswer();
            markedForReview[currentQuestionIndex] = false;
            goToNextQuestion();
        });
        btnClear.addActionListener(e -> clearAnswer());
        btnMarkReviewNext.addActionListener(e -> {
            saveAnswer();
            markedForReview[currentQuestionIndex] = true;
            goToNextQuestion();
        });

        footer.add(btnSaveNext);
        footer.add(btnClear);
        footer.add(btnMarkReviewNext);

        add(footer, BorderLayout.SOUTH);
    }

    private void styleButton(JButton btn, Color bg, Color fg) {
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setPreferredSize(new Dimension(190, 42));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void loadQuestion() {
        lblQuestion.setText("<html><b>Q" + (currentQuestionIndex + 1) + ":</b> " + questions[currentQuestionIndex] + "</html>");
        optionGroup.clearSelection();
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(options[currentQuestionIndex][i]);
        }
        int selected = selectedAnswers[currentQuestionIndex];
        if (selected != -1) {
            optionButtons[selected].setSelected(true);
        }
        updatePaletteColors();
    }

    private void saveAnswer() {
        int selectedOption = -1;
        for (int i = 0; i < 4; i++) {
            if (optionButtons[i].isSelected()) {
                selectedOption = i;
                break;
            }
        }

        selectedAnswers[currentQuestionIndex] = selectedOption;
        updatePaletteColors();

        // Save to database
        saveAnswerToDB(currentQuestionIndex, selectedOption);
    }

    private void clearAnswer() {
        selectedAnswers[currentQuestionIndex] = -1;
        markedForReview[currentQuestionIndex] = false;
        optionGroup.clearSelection();
        updatePaletteColors();
    }

    private void goToNextQuestion() {
        if (currentQuestionIndex < questions.length - 1) {
            currentQuestionIndex++;
            loadQuestion();
        } else {
            JOptionPane.showMessageDialog(this,
                    "You have reached the last question.\nThe exam will submit automatically when time is over.",
                    "End of Questions", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void updatePaletteColors() {
        for (int i = 0; i < questions.length; i++) {
            JButton btn = paletteButtons[i];
            if (markedForReview[i]) {
                btn.setBackground(new Color(186, 85, 211)); // orange for review
            } else if (selectedAnswers[i] != -1) {
                btn.setBackground(new Color(0, 153, 76)); // green for answered
            } else {
                btn.setBackground(Color.LIGHT_GRAY); // default gray
            }
        }
    }

    private void startTimer() {
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            int timeLeft = examDurationSeconds;

            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> {
                    int minutes = timeLeft / 60;
                    int seconds = timeLeft % 60;
                    lblTimer.setText(String.format("Time Left: %02d:%02d", minutes, seconds));
                });

                if (timeLeft <= 0) {
                    timer.cancel();
                    SwingUtilities.invokeLater(() -> {
                        saveAnswer(); // Save current question
                        JOptionPane.showMessageDialog(ExamPanel.this, "Time's up! Your answers have been submitted.", "Time Over", JOptionPane.INFORMATION_MESSAGE);
                        processResults();
                        dispose(); // close the window
                    });
                }

                timeLeft--;
            }
        };
        timer.scheduleAtFixedRate(task, 0, 1000);
    }

    private void saveAnswerToDB(int questionIndex, int selectedOptionIndex) {
        String questionText = questions[questionIndex];
        String selectedOption = selectedOptionIndex == -1 ? null : String.valueOf((char) ('A' + selectedOptionIndex));

        try {
            Conn conn = new Conn();

            // Check if answer already exists
            String checkSQL = "SELECT * FROM student_answers WHERE reg_no = ? AND exam_code = ? AND question_text = ?";
            PreparedStatement checkStmt = conn.c.prepareStatement(checkSQL);
            checkStmt.setString(1, regNo);
            checkStmt.setString(2, examCode);
            checkStmt.setString(3, questionText);

            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // Update existing answer
                String updateSQL = "UPDATE student_answers SET selected_option = ? WHERE reg_no = ? AND exam_code = ? AND question_text = ?";
                PreparedStatement updateStmt = conn.c.prepareStatement(updateSQL);
                updateStmt.setString(1, selectedOption);
                updateStmt.setString(2, regNo);
                updateStmt.setString(3, examCode);
                updateStmt.setString(4, questionText);
                updateStmt.executeUpdate();
                updateStmt.close();
            } else {
                // Insert new answer
                String insertSQL = "INSERT INTO student_answers (reg_no, exam_code, question_text, selected_option) VALUES (?, ?, ?, ?)";
                PreparedStatement insertStmt = conn.c.prepareStatement(insertSQL);
                insertStmt.setString(1, regNo);
                insertStmt.setString(2, examCode);
                insertStmt.setString(3, questionText);
                insertStmt.setString(4, selectedOption);
                insertStmt.executeUpdate();
                insertStmt.close();
            }

            rs.close();
            checkStmt.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error saving answer to database.\n" + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void processResults() {
        int total = 0, correct = 0, wrong = 0;
        int totalQuestions = 0;
        float marksPerQ = 1.0f, negativeMark = 0.0f, fullMarks = 0.0f;
        float score = 0.0f;

        try {
            Conn c = new Conn();

            // Step 1: Get exam settings including total_questions
            String examQuery = "SELECT marks_per_question, negative_marking, full_marks, total_questions FROM exams WHERE exam_code = ?";
            PreparedStatement examPs = c.c.prepareStatement(examQuery);
            examPs.setString(1, examCode);
            ResultSet examRs = examPs.executeQuery();

            if (examRs.next()) {
                marksPerQ = examRs.getFloat("marks_per_question");
                negativeMark = examRs.getFloat("negative_marking");
                fullMarks = examRs.getFloat("full_marks");
                totalQuestions = examRs.getInt("total_questions");
            }

            // Step 2: Get student answers and compare
            String query = "SELECT sa.question_text, sa.selected_option, q.correct_answer "
                    + "FROM student_answers sa "
                    + "JOIN questions q ON sa.exam_code = q.exam_code AND sa.question_text = q.question_text "
                    + "WHERE sa.reg_no = ? AND sa.exam_code = ?";
            PreparedStatement ps = c.c.prepareStatement(query);
            ps.setString(1, regNo);
            ps.setString(2, examCode);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String question = rs.getString("question_text");
                String selected = rs.getString("selected_option");
                String correctAns = rs.getString("correct_answer");

                // Skip unattempted
                if (selected == null || selected.trim().isEmpty()) {
                    continue;
                }

                total++;
                boolean isCorrect = selected.equalsIgnoreCase(correctAns);
                if (isCorrect) {
                    correct++;
                } else {
                    wrong++;
                }

            }

        
            int notAttempted = totalQuestions - total;

       
            score = (correct * marksPerQ) - (wrong * negativeMark);
            score = Math.max(score, 0); // no negative score

    
            String insertQuery = "REPLACE INTO results "
                    + "(reg_no, exam_code, total_questions, attempted, correct, wrong, not_attempted, score, full_marks) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement insertPs = c.c.prepareStatement(insertQuery);
            insertPs.setString(1, regNo);
            insertPs.setString(2, examCode);
            insertPs.setInt(3, totalQuestions);
            insertPs.setInt(4, total);
            insertPs.setInt(5, correct);
            insertPs.setInt(6, wrong);
            insertPs.setInt(7, notAttempted);
            insertPs.setFloat(8, score);
            insertPs.setFloat(9, fullMarks);
            insertPs.executeUpdate();

            dispose();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error processing results: " + e.getMessage());
        }
    }
    public int getExamDurationSeconds(String examCode) {
    int durationMinutes = 0;
    try {
        Conn c = new Conn();
        String query = "SELECT duration FROM exams WHERE exam_code = ?";
        PreparedStatement pst = c.c.prepareStatement(query);
        pst.setString(1, examCode);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            durationMinutes = rs.getInt("duration");
        }

        rs.close();
        pst.close();
        
    } catch (Exception e) {
        e.printStackTrace();
    }
    return durationMinutes * 60;  // convert to seconds
}


    public static void main(String[] args) {
        // Test run with dummy data, repQAlace with actual student/exam info
        SwingUtilities.invokeLater(() -> new ExamPanel("", "", "", ""));
    }
}
