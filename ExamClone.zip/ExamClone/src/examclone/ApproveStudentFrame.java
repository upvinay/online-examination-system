package examclone;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ApproveStudentFrame extends JFrame {

    private JComboBox<String> examComboBox;
    private JButton nextButton, submitButton;
    private JTable studentTable;
    private DefaultTableModel tableModel;
    private JPanel centerPanel;
    private String selectedExamCode;

    public ApproveStudentFrame() {
        setTitle("Approve Students");
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(245, 245, 250));

        Font font = new Font("Segoe UI", Font.PLAIN, 15);

        // ===== Top Panel =====
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        topPanel.setBackground(new Color(230, 240, 250));
        topPanel.setBorder(new TitledBorder(new LineBorder(Color.BLUE, 1, true), "Step 1: Select Exam Code", TitledBorder.CENTER, TitledBorder.TOP, font, Color.DARK_GRAY));

        examComboBox = new JComboBox<>();
        examComboBox.setFont(font);
        examComboBox.setPreferredSize(new Dimension(200, 30));
        loadExamCodes();

        nextButton = new JButton("Next ");
        nextButton.setFont(font);
        nextButton.setBackground(new Color(0, 120, 215));
        nextButton.setForeground(Color.WHITE);
        nextButton.setFocusPainted(false);
        nextButton.setPreferredSize(new Dimension(120, 30));

        topPanel.add(new JLabel("Exam Code:"));
        topPanel.add(examComboBox);
        topPanel.add(nextButton);
        add(topPanel, BorderLayout.NORTH);

        // ===== Center Panel =====
        centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new TitledBorder(new LineBorder(Color.GRAY, 1, true), "Step 2: Approve Students", TitledBorder.LEFT, TitledBorder.TOP, font, Color.DARK_GRAY));
        centerPanel.setVisible(false);
        createStudentTablePanel();
        add(centerPanel, BorderLayout.CENTER);

        // ===== Bottom Panel =====
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(new Color(245, 245, 250));
        submitButton = new JButton(" Submit Approved Students");
        submitButton.setFont(font);
        submitButton.setBackground(new Color(40, 167, 69));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        submitButton.setPreferredSize(new Dimension(250, 35));
        submitButton.setEnabled(false);
        bottomPanel.add(submitButton);
        add(bottomPanel, BorderLayout.SOUTH);

        // ===== Event Listeners =====
        nextButton.addActionListener(e -> {
            selectedExamCode = (String) examComboBox.getSelectedItem();
            if (selectedExamCode == null) {
                JOptionPane.showMessageDialog(this, "Please select an exam code.");
                return;
            }
            centerPanel.setVisible(true);
            submitButton.setEnabled(true);
            loadAllStudents();
        });

        submitButton.addActionListener(e -> submitApprovedStudents());

        setVisible(true);
    }

    private void loadExamCodes() {
        try {
            Conn c = new Conn();
            String query = "SELECT exam_code FROM exams";
            ResultSet rs = c.c.createStatement().executeQuery(query);
            while (rs.next()) {
                examComboBox.addItem(rs.getString("exam_code"));
            }
            rs.close();
            c.c.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading exam codes", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createStudentTablePanel() {
        String[] columns = {"Registration No", "Name", "DOB", "Father Name", "Aadhaar No", "Phone", "Approve"};
        tableModel = new DefaultTableModel(null, columns) {
            public Class<?> getColumnClass(int column) {
                return column == 6 ? Boolean.class : String.class;
            }

            public boolean isCellEditable(int row, int column) {
                return column == 6;
            }
        };

        studentTable = new JTable(tableModel);
        studentTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        studentTable.setRowHeight(28);
        studentTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        studentTable.getTableHeader().setBackground(new Color(100, 149, 237));
        studentTable.getTableHeader().setForeground(Color.WHITE);

        studentTable.setSelectionBackground(new Color(220, 230, 250));

        // Alternating row colors
        studentTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private final Color evenColor = new Color(250, 250, 255);
            private final Color oddColor = new Color(235, 245, 255);

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int col) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
                if (!isSelected) {
                    setBackground(row % 2 == 0 ? evenColor : oddColor);
                }
                return this;
            }
        });

        JScrollPane scrollPane = new JScrollPane(studentTable);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
    }

    private void loadAllStudents() {
        tableModel.setRowCount(0);

        try {
            Conn c = new Conn();
            String query = "SELECT reg_no, name, dob, father_name, aadhar, phone FROM students";
            PreparedStatement ps = c.c.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String reg = rs.getString("reg_no");
                String name = rs.getString("name");
                String dob = rs.getString("dob");
                String father = rs.getString("father_name");
                String aadhaar = rs.getString("aadhar");
                String phone = rs.getString("phone");

                tableModel.addRow(new Object[]{reg, name, dob, father, aadhaar, phone, false});
            }

            rs.close();
            ps.close();
            c.c.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading student records", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void submitApprovedStudents() {
        int approvedCount = 0;

        try {
            Conn c = new Conn();
            String insertQuery = "INSERT INTO studentlogin (reg_no, name, dob, exam_code) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = c.c.prepareStatement(insertQuery);

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                boolean isApproved = (Boolean) tableModel.getValueAt(i, 6);
                if (isApproved) {
                    String regNo = (String) tableModel.getValueAt(i, 0);
                    String name = (String) tableModel.getValueAt(i, 1);
                    String dob = (String) tableModel.getValueAt(i, 2);

                    // Check if this regNo + examCode combination already exists
                    String checkQuery = "SELECT * FROM studentlogin WHERE reg_no = ? AND exam_code = ?";
                    PreparedStatement checkPs = c.c.prepareStatement(checkQuery);
                    checkPs.setString(1, regNo);
                    checkPs.setString(2, selectedExamCode);
                    ResultSet rs = checkPs.executeQuery();

                    if (!rs.next()) {
                        // Not exists, insert the student
                        ps.setString(1, regNo);
                        ps.setString(2, name);
                        ps.setString(3, dob);
                        ps.setString(4, selectedExamCode);

                        ps.executeUpdate();
                        approvedCount++;
                    } else {
                        System.out.println("Duplicate reg_no and exam_code combination found: " + regNo + " for " + selectedExamCode);
                    }

                    rs.close();
                    checkPs.close();
                }
            }

            ps.close();
            c.c.close();

            if (approvedCount > 0) {
                JOptionPane.showMessageDialog(this, approvedCount + " students approved and added to login table successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "No students selected or already approved for this exam.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error while submitting approved students:\n" + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ApproveStudentFrame::new);
    }
}
