package examclone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

public class ScheduleExamFrame extends JFrame {

    private JTextField subjectField, timeField, fullMarksField, perQuestionField, minusMarkField, totalQuestionsField, examCodeField;

    public ScheduleExamFrame() {
        setTitle("Schedule New Exam");
        setSize(600, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        getContentPane().setBackground(new Color(230, 240, 255)); // soft light blue

        JLabel heading = new JLabel("Schedule a New Exam");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 26));
        heading.setForeground(new Color(30, 60, 120));
        heading.setBounds(150, 20, 400, 35);
        add(heading);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 16);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 15);

        // Exam Code
        JLabel codeLbl = new JLabel("Exam Code:");
        codeLbl.setFont(labelFont);
        codeLbl.setForeground(new Color(50, 80, 130));
        codeLbl.setBounds(50, 70, 120, 30);
        add(codeLbl);

        examCodeField = new JTextField(generateExamCode());
        examCodeField.setBounds(210, 70, 200, 30);
        examCodeField.setFont(fieldFont);
        examCodeField.setEditable(false);
        examCodeField.setBackground(new Color(200, 220, 255));
        add(examCodeField);

        // Subject
        JLabel subjectLbl = new JLabel("Subject:");
        subjectLbl.setFont(labelFont);
        subjectLbl.setForeground(new Color(50, 80, 130));
        subjectLbl.setBounds(50, 110, 120, 30);
        add(subjectLbl);

        subjectField = new JTextField();
        subjectField.setBounds(210, 110, 300, 30);
        subjectField.setFont(fieldFont);
        subjectField.setBackground(Color.WHITE);
        add(subjectField);

        // Duration
        JLabel timeLbl = new JLabel("Duration (mins):");
        timeLbl.setFont(labelFont);
        timeLbl.setForeground(new Color(50, 80, 130));
        timeLbl.setBounds(50, 150, 140, 30);
        add(timeLbl);

        timeField = new JTextField();
        timeField.setBounds(210, 150, 100, 30);
        timeField.setFont(fieldFont);
        timeField.setBackground(Color.WHITE);
        add(timeField);

        // Full Marks
        JLabel fullMarksLbl = new JLabel("Full Marks:");
        fullMarksLbl.setFont(labelFont);
        fullMarksLbl.setForeground(new Color(50, 80, 130));
        fullMarksLbl.setBounds(50, 190, 120, 30);
        add(fullMarksLbl);

        fullMarksField = new JTextField();
        fullMarksField.setBounds(210, 190, 100, 30);
        fullMarksField.setFont(fieldFont);
        fullMarksField.setBackground(Color.WHITE);
        add(fullMarksField);

        // Marks per Question
        JLabel perQuesLbl = new JLabel("Marks per Question:");
        perQuesLbl.setFont(labelFont);
        perQuesLbl.setForeground(new Color(50, 80, 130));
        perQuesLbl.setBounds(50, 230, 160, 30);
        add(perQuesLbl);

        perQuestionField = new JTextField();
        perQuestionField.setBounds(210, 230, 100, 30);
        perQuestionField.setFont(fieldFont);
        perQuestionField.setBackground(Color.WHITE);
        add(perQuestionField);

        // Negative Marking
        JLabel minusLbl = new JLabel("Negative Marking:");
        minusLbl.setFont(labelFont);
        minusLbl.setForeground(new Color(50, 80, 130));
        minusLbl.setBounds(50, 270, 160, 30);
        add(minusLbl);

        minusMarkField = new JTextField();
        minusMarkField.setBounds(210, 270, 100, 30);
        minusMarkField.setFont(fieldFont);
        minusMarkField.setBackground(Color.WHITE);
        add(minusMarkField);

        // Total Questions
        JLabel totalQuesLbl = new JLabel("Total Questions:");
        totalQuesLbl.setFont(labelFont);
        totalQuesLbl.setForeground(new Color(50, 80, 130));
        totalQuesLbl.setBounds(50, 310, 160, 30);
        add(totalQuesLbl);

        totalQuestionsField = new JTextField();
        totalQuestionsField.setBounds(210, 310, 100, 30);
        totalQuestionsField.setFont(fieldFont);
        totalQuestionsField.setBackground(Color.WHITE);
        add(totalQuestionsField);

        // Proceed Button
        JButton proceedBtn = new JButton("Add Questions");
        proceedBtn.setBounds(200, 380, 180, 45);
        proceedBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        proceedBtn.setBackground(new Color(70, 130, 180));
        proceedBtn.setForeground(Color.WHITE);
        proceedBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        proceedBtn.setFocusPainted(false);
        add(proceedBtn);

        proceedBtn.addActionListener(e -> handleProceed());
    }

    private void handleProceed() {
        try {
            String code = examCodeField.getText().trim();
            String subject = subjectField.getText().trim();
            int time = Integer.parseInt(timeField.getText().trim());
            float marksPerQ = Float.parseFloat(perQuestionField.getText().trim());
            float minusMark = Float.parseFloat(minusMarkField.getText().trim());
            int fullMarks = Integer.parseInt(fullMarksField.getText().trim());
            int totalQuestions = Integer.parseInt(totalQuestionsField.getText().trim());

            if (subject.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Subject cannot be empty!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (time <= 0 || fullMarks <= 0 || totalQuestions <= 0 || marksPerQ <= 0) {
                JOptionPane.showMessageDialog(this, "Please enter valid positive numbers.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (totalQuestions * marksPerQ != fullMarks) {
                JOptionPane.showMessageDialog(this, "Full Marks must be equal to Total Questions × Marks per Question.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Store in DB
            Conn c = new Conn();
            String sql = "INSERT INTO exams (exam_code, subject, duration, marks_per_question, negative_marking, full_marks, total_questions) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = c.c.prepareStatement(sql);
            pst.setString(1, code);
            pst.setString(2, subject);
            pst.setInt(3, time);
            pst.setFloat(4, marksPerQ);
            pst.setFloat(5, minusMark);
            pst.setInt(6, fullMarks);
            pst.setInt(7, totalQuestions);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Exam scheduled successfully!");

            // Open Add Questions Frame (assumes you’ve implemented AddQuestionsFrame)
            AddQuestionsFrame aqf = new AddQuestionsFrame(code, subject, time, marksPerQ, minusMark, fullMarks, totalQuestions);
            aqf.setVisible(true);
            dispose();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private String generateExamCode() {
        String prefix = "EXAM";
        StringBuilder sb = new StringBuilder();
        Random rand = new Random();
        for (int i = 0; i < 4; i++) {
            sb.append(rand.nextInt(10));
        }
        return prefix + sb.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ScheduleExamFrame().setVisible(true));
    }
}
